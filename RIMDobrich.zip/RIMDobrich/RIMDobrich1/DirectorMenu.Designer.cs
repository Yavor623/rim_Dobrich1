﻿namespace RIMDobrich1
{
    partial class DirectorMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            menuButton = new Button();
            deleteAccountButton = new Button();
            createAccountButton = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(menuButton, 0, 0);
            tableLayoutPanel1.Controls.Add(deleteAccountButton, 0, 2);
            tableLayoutPanel1.Controls.Add(createAccountButton, 0, 1);
            tableLayoutPanel1.Location = new Point(717, 147);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Size = new Size(730, 717);
            tableLayoutPanel1.TabIndex = 4;
            // 
            // menuButton
            // 
            menuButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            menuButton.BackColor = Color.NavajoWhite;
            menuButton.FlatAppearance.BorderSize = 0;
            menuButton.FlatStyle = FlatStyle.Popup;
            menuButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            menuButton.Location = new Point(3, 113);
            menuButton.Name = "menuButton";
            menuButton.Size = new Size(516, 123);
            menuButton.TabIndex = 0;
            menuButton.Text = "Меню";
            menuButton.UseVisualStyleBackColor = false;
            menuButton.Click += menuButton_Click;
            // 
            // deleteAccountButton
            // 
            deleteAccountButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteAccountButton.BackColor = Color.NavajoWhite;
            deleteAccountButton.FlatAppearance.BorderSize = 0;
            deleteAccountButton.FlatStyle = FlatStyle.Popup;
            deleteAccountButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            deleteAccountButton.Location = new Point(3, 591);
            deleteAccountButton.Name = "deleteAccountButton";
            deleteAccountButton.Size = new Size(516, 123);
            deleteAccountButton.TabIndex = 2;
            deleteAccountButton.Text = "Изтриване на акаунт";
            deleteAccountButton.UseVisualStyleBackColor = false;
            deleteAccountButton.Click += deleteAccountButton_Click;
            // 
            // createAccountButton
            // 
            createAccountButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            createAccountButton.BackColor = Color.NavajoWhite;
            createAccountButton.FlatAppearance.BorderSize = 0;
            createAccountButton.FlatStyle = FlatStyle.Popup;
            createAccountButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            createAccountButton.Location = new Point(3, 352);
            createAccountButton.Name = "createAccountButton";
            createAccountButton.Size = new Size(516, 123);
            createAccountButton.TabIndex = 1;
            createAccountButton.Text = "Създаване на акаунт";
            createAccountButton.UseVisualStyleBackColor = false;
            createAccountButton.Click += createAccountButton_Click;
            // 
            // DirectorMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            MinimumSize = new Size(1400, 724);
            Name = "DirectorMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Меню за директори";
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button menuButton;
        private Button deleteAccountButton;
        private Button createAccountButton;
    }
}