﻿namespace RIMDobrich1
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            shapesBtn = new Button();
            sectionsBtn = new Button();
            collectionsBtn = new Button();
            queriesBtn = new Button();
            typesBtn = new Button();
            nameOfMuseumBtn = new Button();
            materialsBtn = new Button();
            artefactsBtn = new Button();
            assesmentProtcolBtn = new Button();
            titleLabel = new Label();
            tableChoiceLabel = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Popup;
            shapesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(3, 569);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(583, 96);
            shapesBtn.TabIndex = 4;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesBtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Popup;
            sectionsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(616, 407);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(599, 96);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.Cursor = Cursors.Hand;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Popup;
            collectionsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(616, 731);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(599, 99);
            collectionsBtn.TabIndex = 8;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsBtn_Click;
            // 
            // queriesBtn
            // 
            queriesBtn.BackColor = Color.NavajoWhite;
            queriesBtn.Cursor = Cursors.Hand;
            queriesBtn.FlatAppearance.BorderSize = 0;
            queriesBtn.FlatStyle = FlatStyle.Popup;
            queriesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            queriesBtn.Location = new Point(1229, 731);
            queriesBtn.Name = "queriesBtn";
            queriesBtn.Size = new Size(603, 99);
            queriesBtn.TabIndex = 9;
            queriesBtn.Text = "Заявки";
            queriesBtn.UseVisualStyleBackColor = false;
            queriesBtn.Click += queriesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Popup;
            typesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(1229, 407);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(603, 96);
            typesBtn.TabIndex = 3;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // nameOfMuseumBtn
            // 
            nameOfMuseumBtn.BackColor = Color.NavajoWhite;
            nameOfMuseumBtn.Cursor = Cursors.Hand;
            nameOfMuseumBtn.FlatAppearance.BorderSize = 0;
            nameOfMuseumBtn.FlatStyle = FlatStyle.Popup;
            nameOfMuseumBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumBtn.Location = new Point(1229, 569);
            nameOfMuseumBtn.Name = "nameOfMuseumBtn";
            nameOfMuseumBtn.Size = new Size(603, 96);
            nameOfMuseumBtn.TabIndex = 6;
            nameOfMuseumBtn.Text = "Музеи";
            nameOfMuseumBtn.UseVisualStyleBackColor = false;
            nameOfMuseumBtn.Click += nameOfMuseumbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Popup;
            materialsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(616, 569);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(599, 96);
            materialsBtn.TabIndex = 5;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Popup;
            artefactsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(3, 407);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(583, 96);
            artefactsBtn.TabIndex = 1;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // assesmentProtcolBtn
            // 
            assesmentProtcolBtn.BackColor = Color.NavajoWhite;
            assesmentProtcolBtn.Cursor = Cursors.Hand;
            assesmentProtcolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtcolBtn.FlatStyle = FlatStyle.Popup;
            assesmentProtcolBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtcolBtn.Location = new Point(3, 731);
            assesmentProtcolBtn.Name = "assesmentProtcolBtn";
            assesmentProtcolBtn.Size = new Size(583, 99);
            assesmentProtcolBtn.TabIndex = 7;
            assesmentProtcolBtn.Text = "Оценителен протоколи";
            assesmentProtcolBtn.UseVisualStyleBackColor = false;
            assesmentProtcolBtn.Click += assesmentProtcolBtn_Click;
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(titleLabel, 3);
            titleLabel.Font = new Font("Gabriola", 45.2F, FontStyle.Bold, GraphicsUnit.Point);
            titleLabel.Location = new Point(3, 0);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(1148, 140);
            titleLabel.TabIndex = 3;
            titleLabel.Text = "Добре дошли в системата на РИМ-Добрич";
            // 
            // tableChoiceLabel
            // 
            tableChoiceLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(tableChoiceLabel, 3);
            tableChoiceLabel.Font = new Font("Gabriola", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            tableChoiceLabel.Location = new Point(3, 202);
            tableChoiceLabel.Name = "tableChoiceLabel";
            tableChoiceLabel.Size = new Size(786, 81);
            tableChoiceLabel.TabIndex = 4;
            tableChoiceLabel.Text = "Изберете таблицата, в която искате да влезете";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33333F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanel1.Controls.Add(assesmentProtcolBtn, 0, 4);
            tableLayoutPanel1.Controls.Add(collectionsBtn, 1, 4);
            tableLayoutPanel1.Controls.Add(titleLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(queriesBtn, 2, 4);
            tableLayoutPanel1.Controls.Add(tableChoiceLabel, 0, 1);
            tableLayoutPanel1.Controls.Add(materialsBtn, 1, 3);
            tableLayoutPanel1.Controls.Add(nameOfMuseumBtn, 2, 3);
            tableLayoutPanel1.Controls.Add(shapesBtn, 0, 3);
            tableLayoutPanel1.Controls.Add(typesBtn, 2, 2);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 0, 2);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 1, 2);
            tableLayoutPanel1.Location = new Point(50, 64);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 22.727272F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 22.727272F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18.181818F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18.181818F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18.181818F));
            tableLayoutPanel1.Size = new Size(1840, 893);
            tableLayoutPanel1.TabIndex = 5;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1924, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1300, 724);
            Name = "Menu";
            Text = "Меню";
            WindowState = FormWindowState.Maximized;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button shapesBtn;
        private Button sectionsBtn;
        private Label titleLabel;
        private Label tableChoiceLabel;
        private Button nameOfMuseumBtn;
        private Button typesBtn;
        private Button artefactsBtn;
        private Button assesmentProtcolBtn;
        private Button materialsBtn;
        private Button queriesBtn;
        private Button collectionsBtn;
        private TableLayoutPanel tableLayoutPanel1;
    }
}