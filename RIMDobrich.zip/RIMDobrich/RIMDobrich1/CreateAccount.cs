﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class CreateAccount : Form
    {
        public string DirectorPassword { get; set; }
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        MySqlDataReader sqlRd;
        String sqlQuery;
        public CreateAccount()
        {
            InitializeComponent();
        }
        public CreateAccount(string directorPassword)
        {
            this.DirectorPassword = directorPassword;
            InitializeComponent();
        }

        private void signInLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignInForm signInForm = new SignInForm();
            CreateAccount signUpForm = new CreateAccount();
            signInForm.Show();
            this.Hide();
            signUpForm.Close();
        }

        private void registrationButton_Click(object sender, EventArgs e)
        {

            int idOfMuseum = nameOfMuseumComboBox.SelectedIndex + 1;
            int privilegeInt = privilegesComboBox.SelectedIndex + 1;
            CreateAccountProtection createAccountProtection = new CreateAccountProtection(DirectorPassword, firstNameTextBox.Text, lastNameTextBox.Text, usernameTextBox.Text, passwordTextBox.Text, privilegeInt, emailTextBox.Text, dateOfBirth.Text, idOfMuseum);
            createAccountProtection.Show();
        }
        public void UploadComboBoxPrivileges() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.privileges"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                privilegesComboBox.Items.Add(reader.GetString("privilege_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataNameOfMuseum() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.nameofmuseum"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                nameOfMuseumComboBox.Items.Add(reader.GetString("museum_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }

        private void directorMenuLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            CreateAccount createAccount = new CreateAccount();
            directorMenu.Show();
            this.Hide();
            createAccount.Close();
        }

        private void CreateAccount_Load(object sender, EventArgs e)
        {
            UploadComboBoxDataNameOfMuseum();
            UploadComboBoxPrivileges();
        }
    }
}
