﻿namespace RIMDobrich1
{
    partial class Types
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Types));
            searchBtn = new Button();
            searchTxt = new TextBox();
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            typeNameTxt = new TextBox();
            typesDataGrid = new DataGridView();
            assesmentProtocolBtn = new Button();
            collectionsBtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesBtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            resetBtn = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            indexTxt = new TextBox();
            ((System.ComponentModel.ISupportInitialize)typesDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(searchBtn, 3);
            searchBtn.Cursor = Cursors.Hand;
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Modern No. 20", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchBtn.Location = new Point(3, 451);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(520, 60);
            searchBtn.TabIndex = 35;
            searchBtn.TabStop = false;
            searchBtn.Text = "Търси";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchbtn_Click_1;
            // 
            // searchTxt
            // 
            tableLayoutPanel1.SetColumnSpan(searchTxt, 3);
            searchTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(3, 339);
            searchTxt.Multiline = true;
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търсене";
            searchTxt.Size = new Size(520, 60);
            searchTxt.TabIndex = 34;
            searchTxt.TabStop = false;
            searchTxt.KeyDown += indexTxt_KeyDown;
            // 
            // updateBtn
            // 
            updateBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            updateBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updateBtn, 3);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(3, 706);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(520, 75);
            updateBtn.TabIndex = 33;
            updateBtn.TabStop = false;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click_1;
            // 
            // deleteBtn
            // 
            deleteBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deleteBtn, 3);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(3, 818);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(520, 75);
            deleteBtn.TabIndex = 32;
            deleteBtn.TabStop = false;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click_1;
            // 
            // addNewBtn
            // 
            addNewBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            addNewBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewBtn, 3);
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(3, 594);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(520, 75);
            addNewBtn.TabIndex = 31;
            addNewBtn.TabStop = false;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click_1;
            // 
            // typeNameTxt
            // 
            tableLayoutPanel1.SetColumnSpan(typeNameTxt, 3);
            typeNameTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            typeNameTxt.Location = new Point(3, 227);
            typeNameTxt.Multiline = true;
            typeNameTxt.Name = "typeNameTxt";
            typeNameTxt.PlaceholderText = "Име на вид";
            typeNameTxt.Size = new Size(520, 60);
            typeNameTxt.TabIndex = 30;
            typeNameTxt.TabStop = false;
            typeNameTxt.KeyDown += indexTxt_KeyDown;
            // 
            // typesDataGrid
            // 
            typesDataGrid.AllowUserToAddRows = false;
            typesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            typesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            typesDataGrid.BackgroundColor = Color.Tan;
            typesDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            typesDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(typesDataGrid, 7);
            typesDataGrid.Cursor = Cursors.PanNW;
            typesDataGrid.GridColor = Color.IndianRed;
            typesDataGrid.Location = new Point(555, 115);
            typesDataGrid.Name = "typesDataGrid";
            typesDataGrid.ReadOnly = true;
            typesDataGrid.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Beige;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            typesDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            typesDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(typesDataGrid, 8);
            typesDataGrid.RowTemplate.Height = 29;
            typesDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            typesDataGrid.Size = new Size(1287, 895);
            typesDataGrid.TabIndex = 28;
            typesDataGrid.TabStop = false;
            typesDataGrid.CellClick += typesDataGrid_CellClick_1;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Popup;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1291, 3);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(178, 49);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.TabStop = false;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.Cursor = Cursors.Hand;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Popup;
            collectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(1475, 3);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(178, 49);
            collectionsBtn.TabIndex = 34;
            collectionsBtn.TabStop = false;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Popup;
            museumsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1107, 3);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(178, 49);
            museumsBtn.TabIndex = 33;
            museumsBtn.TabStop = false;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Popup;
            artefactsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(187, 3);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 49);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.TabStop = false;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesBtn
            // 
            quieriesBtn.BackColor = Color.NavajoWhite;
            quieriesBtn.Cursor = Cursors.Hand;
            quieriesBtn.FlatAppearance.BorderSize = 0;
            quieriesBtn.FlatStyle = FlatStyle.Popup;
            quieriesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesBtn.Location = new Point(1659, 3);
            quieriesBtn.Name = "quieriesBtn";
            quieriesBtn.Size = new Size(178, 49);
            quieriesBtn.TabIndex = 31;
            quieriesBtn.TabStop = false;
            quieriesBtn.Text = "Заявки";
            quieriesBtn.UseVisualStyleBackColor = false;
            quieriesBtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Popup;
            materialsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(923, 3);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(178, 49);
            materialsBtn.TabIndex = 30;
            materialsBtn.TabStop = false;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Popup;
            shapesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(739, 3);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(178, 49);
            shapesBtn.TabIndex = 29;
            shapesBtn.TabStop = false;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.Enabled = false;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Popup;
            typesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(555, 3);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(178, 49);
            typesBtn.TabIndex = 28;
            typesBtn.TabStop = false;
            typesBtn.Text = "Видове";
            typesBtn.UseVisualStyleBackColor = false;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Popup;
            sectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(371, 3);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(178, 49);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.TabStop = false;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Popup;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(178, 49);
            menuBtn.TabIndex = 0;
            menuBtn.TabStop = false;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // resetBtn
            // 
            resetBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(3, 935);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(520, 75);
            resetBtn.TabIndex = 42;
            resetBtn.TabStop = false;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(indexTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(resetBtn, 0, 8);
            tableLayoutPanel1.Controls.Add(quieriesBtn, 9, 0);
            tableLayoutPanel1.Controls.Add(deleteBtn, 0, 7);
            tableLayoutPanel1.Controls.Add(updateBtn, 0, 6);
            tableLayoutPanel1.Controls.Add(searchBtn, 0, 4);
            tableLayoutPanel1.Controls.Add(collectionsBtn, 8, 0);
            tableLayoutPanel1.Controls.Add(addNewBtn, 0, 5);
            tableLayoutPanel1.Controls.Add(searchTxt, 0, 3);
            tableLayoutPanel1.Controls.Add(assesmentProtocolBtn, 7, 0);
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(museumsBtn, 6, 0);
            tableLayoutPanel1.Controls.Add(typeNameTxt, 0, 2);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(typesBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(materialsBtn, 5, 0);
            tableLayoutPanel1.Controls.Add(shapesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(typesDataGrid, 3, 1);
            tableLayoutPanel1.Location = new Point(12, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 9;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.11111F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.1111116F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.11111F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(1845, 1013);
            tableLayoutPanel1.TabIndex = 43;
            // 
            // indexTxt
            // 
            tableLayoutPanel1.SetColumnSpan(indexTxt, 3);
            indexTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            indexTxt.Location = new Point(3, 115);
            indexTxt.Multiline = true;
            indexTxt.Name = "indexTxt";
            indexTxt.PlaceholderText = "Индекс";
            indexTxt.Size = new Size(520, 60);
            indexTxt.TabIndex = 43;
            indexTxt.TabStop = false;
            // 
            // Types
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1024, 724);
            Name = "Types";
            Text = "Видове артефакти";
            WindowState = FormWindowState.Maximized;
            Load += Types_Load;
            ((System.ComponentModel.ISupportInitialize)typesDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button searchBtn;
        private TextBox searchTxt;
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private TextBox typeNameTxt;
        private DataGridView typesDataGrid;
        private BindingSource bindingSource1;
        private Button assesmentProtocolBtn;
        private Button collectionsBtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesBtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button resetBtn;
        private TableLayoutPanel tableLayoutPanel1;
        private TextBox indexTxt;
    }
}