﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class CreateAccountProtection : Form
    {
        public string DirectorPassword { get; set; }
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Password { get; set; }
        public int PrivilegeId { get; set; }
        public string Email { get; set; }
        public string DateOfBirth { get; set; }
        public int IdOfMuseum { get; set; }
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        MySqlDataReader sqlRd;
        String sqlQuery;
        public CreateAccountProtection()
        {
            InitializeComponent();
        }

        public CreateAccountProtection(string directorPassword, string firstName, string lastName, string username, string password, int privilegeId, string email, string dateOfBirth, int idOfMuseum)
        {
            this.DirectorPassword = directorPassword;
            this.Username = username;
            this.LastName = lastName;
            this.Password = password;
            this.PrivilegeId = privilegeId;
            this.Email = email;
            this.DateOfBirth = dateOfBirth;
            this.IdOfMuseum = idOfMuseum;
            this.FirstName = firstName;
            InitializeComponent();
        }

        private void deleteAccountReadyButton_Click(object sender, EventArgs e)
        {
            if (DirectorPassword == passwordTextBox.Text)
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                try
                {
                    sqlConn.Open();

                    //Вмъква в таблицата materials съответните стойности
                    sqlQuery = $"INSERT INTO rim_dobrich.users(firstName,lastName,username,password,privilegeId,email,dateOfBirth,nameofmuseum_id) VALUES('{FirstName}','{LastName}','{Username}','{Password}','{PrivilegeId}','{Email}','{DateOfBirth}','{IdOfMuseum}')";
                    sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                    sqlRd = sqlCmd.ExecuteReader();
                    sqlConn.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Неуспешно добавяне", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally { sqlConn.Close(); }
                CreateAccount createAccount = new CreateAccount();
                CreateAccountProtection createAccountProtection = new CreateAccountProtection();
                createAccount.Show();
                this.Hide();
                createAccountProtection.Close();
            }
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }
    }
}
