﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class Restoration : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataReader sqlRd;
        string beforePictureName;
        string afterPictureName;
        string beforePictureFullDirection;
        string afterPictureFullDirection;
        String chosenPictureAddress = Directory.GetCurrentDirectory();
        public Restoration()
        {
            InitializeComponent();
        }

        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.restorationDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.restorationDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.restorationDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.restorationDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.restorationDataGrid.GridColor = Color.BlueViolet;
        }

        //Избира данните от таблицата materials и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT inventory_id AS 'Инв. номер', property AS 'Собственост', origin AS 'Произход', dateofentry AS 'Дата на постъпване',dating AS 'Датировка',size AS 'Размери',rim_dobrich.materials.material_name AS 'Материал',reasonsforentry AS 'Причини за постъпване',reportsofpastconservation AS 'Сведения за предшестващи консерв. и др. намеси',protocoloftheconservationcouncill AS 'Протокол на консерв. съвет, с който е одобрено предложението',descriptionoftheitem AS 'Описание на муз. предмет преди започване на обработка ',descriptionoftheconservation AS 'Описание на консерв. и реставр. работа',protocoloftheconservationcouncilwithwhichitwasaccepted AS 'Протокол на консерв. съвет, с който е приета обработка на ДПК ',recommendationforconservation AS 'Препоръки са съхраняване',beforepicture AS 'снимка преди',afterpicture AS 'снимка след' FROM rim_dobrich.restoration " +
                "LEFT JOIN rim_dobrich.materials ON rim_dobrich.materials.material_id=rim_dobrich.restoration.material_id";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            restorationDataGrid.DataSource = sqlDT;
        }
        public void UploadComboBoxDataMaterials() //Добавя елементите на комбобокса от таблицата materials
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.materials"; //Избира всичко от таблицата materials
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                materialComboBox.Items.Add(reader.GetString("material_name")); //Добавя елементите от колоната material_name в комбобокса
            }
            sqlConn.Close();
        }

        private void beforePictureBtn_Click(object sender, EventArgs e)
        {
            if (openBeforePicture.ShowDialog() == DialogResult.OK)
            {
                beforePicture.ImageLocation = openBeforePicture.FileName.ToString();
                beforePictureName = Path.GetFileName(openBeforePicture.FileName);
            }
        }
        private void afterPictureBtn_Click(object sender, EventArgs e)
        {
            if (openAfterPicture.ShowDialog() == DialogResult.OK)
            {
                afterPicture.ImageLocation = openAfterPicture.FileName.ToString();
                afterPictureName = Path.GetFileName(openAfterPicture.FileName);
            }
        }

        private void Restoration_Load(object sender, EventArgs e)
        {
            UploadData();
            UploadComboBoxDataMaterials();
        }

        private void addNewBtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            try
            {
                sqlConn.Open();

                //Вмъква в таблицата materials съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.restoration(inventory_id,property,origin,dateofentry,dating,size,material_id,reasonsforentry,reportsofpastconservation,protocoloftheconservationcouncill,descriptionoftheitem,descriptionoftheconservation,protocoloftheconservationcouncilwithwhichitwasaccepted,recommendationforconservation,beforepicture,afterpicture) VALUES('{inventoryId.Text}','{property.Text}','{origin.Text}','{dateOfEntry.Text}','{dating.Text}'," +
                    $"'{size.Text}','{materialComboBox.SelectedIndex + 1}','{reasonsForEntry.Text}','{reportsofpastconservation.Text}','{protocoloftheconservationcouncill.Text}','{descriptionoftheitem.Text}','{descriptionoftheconservation.Text}','{protocoloftheconservationcouncilwithwhichitwasaccepted.Text}','{recommendationforconservation.Text}','{beforePictureName}','{afterPictureName}')";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

                MessageBox.Show($"Успешно добавяне", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                inventoryId.Text = string.Empty;
                property.Text = string.Empty;
                origin.Text = string.Empty;
                dateOfEntry.Text = string.Empty;
                dating.Text = string.Empty;
                size.Text = string.Empty;
                materialComboBox.Text = "Материал";
                reasonsForEntry.Text = string.Empty;
                reportsofpastconservation.Text = string.Empty;
                protocoloftheconservationcouncill.Text = string.Empty;
                descriptionoftheitem.Text = string.Empty;
                descriptionoftheconservation.Text = string.Empty;
                protocoloftheconservationcouncilwithwhichitwasaccepted.Text = string.Empty;
                recommendationforconservation.Text = string.Empty;
                beforePicture.ImageLocation = null;
                afterPicture.ImageLocation = null;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            //try
            //{

            MySqlCommand sqlCmd = new MySqlCommand();
            sqlCmd.Connection = sqlConn;

            //Обновява таблицата assesmentprotocol 
            sqlCmd.CommandText = "UPDATE rim_dobrich.restoration SET inventory_id =@inventory_id , property=@property, origin=@origin, dateofentry=@dateofentry, dating=@dating, size=@size,material_id=@material_id,reasonsforentry=@reasonsforentry,reportsofpastconservation=@reportsofpastconservation," +
                "protocoloftheconservationcouncill=@protocoloftheconservationcouncill,descriptionoftheitem=@descriptionoftheitem,descriptionoftheconservation=@descriptionoftheconservation,protocoloftheconservationcouncilwithwhichitwasaccepted=@protocoloftheconservationcouncilwithwhichitwasaccepted," +
                "recommendationforconservation=@recommendationforconservation,beforepicture=@beforepicture,afterpicture=@afterpicture WHERE inventory_id=@inventory_id";
            sqlCmd.CommandType = CommandType.Text;

            //Стойностите, които ще заменят старите при обновяването
            sqlCmd.Parameters.AddWithValue("@inventory_id", inventoryId.Text);
            sqlCmd.Parameters.AddWithValue("@property", property.Text);
            sqlCmd.Parameters.AddWithValue("@origin", origin.Text);
            sqlCmd.Parameters.AddWithValue("@dateofentry", dateOfEntry.Text);
            sqlCmd.Parameters.AddWithValue("@dating", dating.Text);
            sqlCmd.Parameters.AddWithValue("@size", size.Text);
            sqlCmd.Parameters.AddWithValue("@material_id", materialComboBox.SelectedIndex + 1);
            sqlCmd.Parameters.AddWithValue("@reasonsforentry", reasonsForEntry.Text);
            sqlCmd.Parameters.AddWithValue("@reportsofpastconservation", reportsofpastconservation.Text);
            sqlCmd.Parameters.AddWithValue("@protocoloftheconservationcouncill", protocoloftheconservationcouncill.Text);
            sqlCmd.Parameters.AddWithValue("@descriptionoftheitem", descriptionoftheitem.Text);
            sqlCmd.Parameters.AddWithValue("@descriptionoftheconservation", descriptionoftheconservation.Text);
            sqlCmd.Parameters.AddWithValue("@protocoloftheconservationcouncilwithwhichitwasaccepted", protocoloftheconservationcouncilwithwhichitwasaccepted.Text);
            sqlCmd.Parameters.AddWithValue("@recommendationforconservation", recommendationforconservation.Text);
            sqlCmd.Parameters.AddWithValue("@beforepicture", beforePictureName);
            sqlCmd.Parameters.AddWithValue("@afterpicture", afterPictureName);

            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();

            MessageBox.Show($"Успешно обновяване", "", MessageBoxButtons.OK);

            //Връща началните стойности, занулира
            inventoryId.Text = string.Empty;
            property.Text = string.Empty;
            origin.Text = string.Empty;
            dateOfEntry.Text = string.Empty;
            dating.Text = string.Empty;
            size.Text = string.Empty;
            materialComboBox.Text = "Материал";
            reasonsForEntry.Text = string.Empty;
            reportsofpastconservation.Text = string.Empty;
            protocoloftheconservationcouncill.Text = string.Empty;
            descriptionoftheitem.Text = string.Empty;
            descriptionoftheconservation.Text = string.Empty;
            protocoloftheconservationcouncilwithwhichitwasaccepted.Text = string.Empty;
            recommendationforconservation.Text = string.Empty;
            beforePicture.ImageLocation = null;
            afterPicture.ImageLocation = null;
            UploadData();

            //}
            /*catch (Exception elex)
            {
                MessageBox.Show($"Неуспешно обновяване", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }*/
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата assesmentprotocol реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.restoration WHERE inventory_id={inventoryId.Text};";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                MessageBox.Show($"Успешно премахване", "", MessageBoxButtons.OK);
                foreach (DataGridViewRow item in this.restorationDataGrid.SelectedRows)
                {
                    restorationDataGrid.Rows.RemoveAt(item.Index);

                }
                //Връща началните стойности, занулира
                inventoryId.Text = string.Empty;
                property.Text = string.Empty;
                origin.Text = string.Empty;
                dateOfEntry.Text = string.Empty;
                dating.Text = string.Empty;
                size.Text = string.Empty;
                materialComboBox.Text = "Материал";
                reasonsForEntry.Text = string.Empty;
                reportsofpastconservation.Text = string.Empty;
                protocoloftheconservationcouncill.Text = string.Empty;
                descriptionoftheitem.Text = string.Empty;
                descriptionoftheconservation.Text = string.Empty;
                protocoloftheconservationcouncilwithwhichitwasaccepted.Text = string.Empty;
                recommendationforconservation.Text = string.Empty;
                beforePicture.ImageLocation = null;
                afterPicture.ImageLocation = null;
                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно премахване", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            inventoryId.Text = string.Empty;
            property.Text = string.Empty;
            origin.Text = string.Empty;
            dateOfEntry.Text = string.Empty;
            dating.Text = string.Empty;
            size.Text = string.Empty;
            materialComboBox.Text = string.Empty;
            reasonsForEntry.Text = string.Empty;
            reportsofpastconservation.Text = string.Empty;
            protocoloftheconservationcouncill.Text = string.Empty;
            descriptionoftheitem.Text = string.Empty;
            descriptionoftheconservation.Text = string.Empty;
            protocoloftheconservationcouncilwithwhichitwasaccepted.Text = string.Empty;
            recommendationforconservation.Text = string.Empty;
            beforePicture.ImageLocation = null;
            afterPicture.ImageLocation = null;
        }

        private void restorationDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            inventoryId.Text = restorationDataGrid.SelectedRows[0].Cells[0].Value.ToString();
            property.Text = restorationDataGrid.SelectedRows[0].Cells[1].Value.ToString();
            origin.Text = restorationDataGrid.SelectedRows[0].Cells[2].Value.ToString();
            dateOfEntry.Text = restorationDataGrid.SelectedRows[0].Cells[3].Value.ToString();
            dating.Text = restorationDataGrid.SelectedRows[0].Cells[4].Value.ToString();
            size.Text = restorationDataGrid.SelectedRows[0].Cells[5].Value.ToString();
            materialComboBox.Text = restorationDataGrid.SelectedRows[0].Cells[6].Value.ToString();
            reasonsForEntry.Text = restorationDataGrid.SelectedRows[0].Cells[7].Value.ToString();
            reportsofpastconservation.Text = restorationDataGrid.SelectedRows[0].Cells[8].Value.ToString();
            protocoloftheconservationcouncill.Text = restorationDataGrid.SelectedRows[0].Cells[9].Value.ToString();
            descriptionoftheitem.Text = restorationDataGrid.SelectedRows[0].Cells[10].Value.ToString();
            descriptionoftheconservation.Text = restorationDataGrid.SelectedRows[0].Cells[11].Value.ToString();
            protocoloftheconservationcouncilwithwhichitwasaccepted.Text = restorationDataGrid.SelectedRows[0].Cells[12].Value.ToString();
            recommendationforconservation.Text = restorationDataGrid.SelectedRows[0].Cells[13].Value.ToString();
            beforePictureName = restorationDataGrid.SelectedRows[0].Cells[14].Value.ToString();
            beforePictureFullDirection = chosenPictureAddress + "\\MuseumPictures\\" + beforePictureName;
            beforePicture.ImageLocation = beforePictureFullDirection;
            afterPictureName = restorationDataGrid.SelectedRows[0].Cells[15].Value.ToString();
            afterPictureFullDirection = chosenPictureAddress + "\\MuseumPictures\\" + afterPictureName;
            afterPicture.ImageLocation = afterPictureFullDirection;
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                DataView dv = sqlDT.DefaultView;
                dv.RowFilter = string.Format("`Инв. номер` like'%{0}%'", searchTxt.Text);
                restorationDataGrid.DataSource = dv.ToTable();
                UploadData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
