﻿namespace RIMDobrich1
{
    partial class Materials
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Materials));
            assesmentProtocolBtn = new Button();
            collectionsbtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesbtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            materialDataGrid = new DataGridView();
            materialTxt = new TextBox();
            materialIdTxt = new TextBox();
            resetBtn = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Popup;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1291, 3);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(178, 49);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.TabStop = false;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsbtn
            // 
            collectionsbtn.BackColor = Color.NavajoWhite;
            collectionsbtn.Cursor = Cursors.Hand;
            collectionsbtn.FlatAppearance.BorderSize = 0;
            collectionsbtn.FlatStyle = FlatStyle.Popup;
            collectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsbtn.Location = new Point(1475, 3);
            collectionsbtn.Name = "collectionsbtn";
            collectionsbtn.Size = new Size(178, 49);
            collectionsbtn.TabIndex = 34;
            collectionsbtn.TabStop = false;
            collectionsbtn.Text = "Сбирки";
            collectionsbtn.UseVisualStyleBackColor = false;
            collectionsbtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Popup;
            museumsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1107, 3);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(178, 49);
            museumsBtn.TabIndex = 33;
            museumsBtn.TabStop = false;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += nameOfMuseumbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Popup;
            artefactsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(187, 3);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 49);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.TabStop = false;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesbtn
            // 
            quieriesbtn.BackColor = Color.NavajoWhite;
            quieriesbtn.Cursor = Cursors.Hand;
            quieriesbtn.FlatAppearance.BorderSize = 0;
            quieriesbtn.FlatStyle = FlatStyle.Popup;
            quieriesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesbtn.Location = new Point(1659, 3);
            quieriesbtn.Name = "quieriesbtn";
            quieriesbtn.Size = new Size(181, 49);
            quieriesbtn.TabIndex = 31;
            quieriesbtn.TabStop = false;
            quieriesbtn.Text = "Заявки";
            quieriesbtn.UseVisualStyleBackColor = false;
            quieriesbtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.Enabled = false;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Popup;
            materialsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(923, 3);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(178, 49);
            materialsBtn.TabIndex = 30;
            materialsBtn.TabStop = false;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Popup;
            shapesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(739, 3);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(178, 49);
            shapesBtn.TabIndex = 29;
            shapesBtn.TabStop = false;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Popup;
            typesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(555, 3);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(178, 49);
            typesBtn.TabIndex = 28;
            typesBtn.TabStop = false;
            typesBtn.Text = "Видове ";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Popup;
            sectionsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(371, 3);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(178, 49);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.TabStop = false;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Popup;
            menuBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(178, 49);
            menuBtn.TabIndex = 0;
            menuBtn.TabStop = false;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updateBtn, 3);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.Dock = DockStyle.Bottom;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(3, 576);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(546, 75);
            updateBtn.TabIndex = 47;
            updateBtn.TabStop = false;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deleteBtn, 3);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.Dock = DockStyle.Bottom;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(3, 717);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(546, 75);
            deleteBtn.TabIndex = 46;
            deleteBtn.TabStop = false;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click;
            // 
            // addNewBtn
            // 
            addNewBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewBtn, 3);
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.Dock = DockStyle.Bottom;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(3, 435);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(546, 75);
            addNewBtn.TabIndex = 45;
            addNewBtn.TabStop = false;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click;
            // 
            // materialDataGrid
            // 
            materialDataGrid.AccessibleRole = AccessibleRole.None;
            materialDataGrid.AllowUserToAddRows = false;
            materialDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            materialDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            materialDataGrid.BackgroundColor = Color.Tan;
            materialDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(materialDataGrid, 7);
            materialDataGrid.Cursor = Cursors.PanNW;
            materialDataGrid.Location = new Point(555, 93);
            materialDataGrid.Name = "materialDataGrid";
            materialDataGrid.ReadOnly = true;
            materialDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(materialDataGrid, 6);
            materialDataGrid.RowTemplate.Height = 29;
            materialDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            materialDataGrid.Size = new Size(1285, 844);
            materialDataGrid.TabIndex = 44;
            materialDataGrid.TabStop = false;
            materialDataGrid.CellClick += descriprionDataGrid_CellClick;
            // 
            // materialTxt
            // 
            tableLayoutPanel1.SetColumnSpan(materialTxt, 3);
            materialTxt.Dock = DockStyle.Bottom;
            materialTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            materialTxt.Location = new Point(3, 309);
            materialTxt.Multiline = true;
            materialTxt.Name = "materialTxt";
            materialTxt.PlaceholderText = "Име на материал";
            materialTxt.Size = new Size(546, 60);
            materialTxt.TabIndex = 43;
            materialTxt.TabStop = false;
            materialTxt.KeyDown += materialIdTxt_KeyDown;
            // 
            // materialIdTxt
            // 
            tableLayoutPanel1.SetColumnSpan(materialIdTxt, 3);
            materialIdTxt.Dock = DockStyle.Bottom;
            materialIdTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            materialIdTxt.Location = new Point(3, 168);
            materialIdTxt.Multiline = true;
            materialIdTxt.Name = "materialIdTxt";
            materialIdTxt.PlaceholderText = "Индекс";
            materialIdTxt.Size = new Size(546, 60);
            materialIdTxt.TabIndex = 42;
            materialIdTxt.TabStop = false;
            materialIdTxt.KeyDown += materialIdTxt_KeyDown;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.Dock = DockStyle.Bottom;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(3, 862);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(546, 75);
            resetBtn.TabIndex = 49;
            resetBtn.TabStop = false;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(quieriesbtn, 9, 0);
            tableLayoutPanel1.Controls.Add(collectionsbtn, 8, 0);
            tableLayoutPanel1.Controls.Add(assesmentProtocolBtn, 7, 0);
            tableLayoutPanel1.Controls.Add(resetBtn, 0, 6);
            tableLayoutPanel1.Controls.Add(deleteBtn, 0, 5);
            tableLayoutPanel1.Controls.Add(museumsBtn, 6, 0);
            tableLayoutPanel1.Controls.Add(updateBtn, 0, 4);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(materialsBtn, 5, 0);
            tableLayoutPanel1.Controls.Add(shapesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(materialTxt, 0, 2);
            tableLayoutPanel1.Controls.Add(typesBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(materialIdTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(addNewBtn, 0, 3);
            tableLayoutPanel1.Controls.Add(materialDataGrid, 3, 1);
            tableLayoutPanel1.Location = new Point(28, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 9.644771F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.0592041F));
            tableLayoutPanel1.Size = new Size(1843, 940);
            tableLayoutPanel1.TabIndex = 50;
            // 
            // Materials
            // 
            AutoScaleDimensions = new SizeF(120F, 120F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1024, 724);
            Name = "Materials";
            RightToLeft = RightToLeft.No;
            Text = "Материали";
            Load += Materials_Load;
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button assesmentProtocolBtn;
        private Button collectionsbtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesbtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private DataGridView materialDataGrid;
        private TextBox materialTxt;
        private TextBox materialIdTxt;
        private Button resetBtn;
        private TableLayoutPanel tableLayoutPanel1;
    }
}