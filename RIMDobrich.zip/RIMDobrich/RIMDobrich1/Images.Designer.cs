﻿namespace RIMDobrich1
{
    partial class Images
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox = new PictureBox();
            pictureBtn = new Button();
            openFileDialog1 = new OpenFileDialog();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            pictureBox2 = new PictureBox();
            button3 = new Button();
            pictureBox3 = new PictureBox();
            button4 = new Button();
            pictureBox4 = new PictureBox();
            button5 = new Button();
            pictureBox5 = new PictureBox();
            artefactsBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // pictureBox
            // 
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.Location = new Point(399, 361);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(366, 253);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.TabIndex = 79;
            pictureBox.TabStop = false;
            // 
            // pictureBtn
            // 
            pictureBtn.BackColor = Color.NavajoWhite;
            pictureBtn.Cursor = Cursors.Hand;
            pictureBtn.FlatStyle = FlatStyle.Flat;
            pictureBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            pictureBtn.Location = new Point(399, 620);
            pictureBtn.Name = "pictureBtn";
            pictureBtn.Size = new Size(366, 38);
            pictureBtn.TabIndex = 80;
            pictureBtn.TabStop = false;
            pictureBtn.Text = "Добави снимка";
            pictureBtn.UseVisualStyleBackColor = false;
            pictureBtn.Click += pictureBtn_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // button1
            // 
            button1.BackColor = Color.NavajoWhite;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(399, 290);
            button1.Name = "button1";
            button1.Size = new Size(366, 38);
            button1.TabIndex = 82;
            button1.TabStop = false;
            button1.Text = "Добави снимка";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(399, 31);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(366, 253);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 81;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.NavajoWhite;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(781, 620);
            button2.Name = "button2";
            button2.Size = new Size(366, 38);
            button2.TabIndex = 84;
            button2.TabStop = false;
            button2.Text = "Добави снимка";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BorderStyle = BorderStyle.FixedSingle;
            pictureBox2.Location = new Point(781, 361);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(366, 253);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 83;
            pictureBox2.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.NavajoWhite;
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(27, 620);
            button3.Name = "button3";
            button3.Size = new Size(366, 38);
            button3.TabIndex = 86;
            button3.TabStop = false;
            button3.Text = "Добави снимка";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
            pictureBox3.Location = new Point(27, 361);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(366, 253);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 85;
            pictureBox3.TabStop = false;
            // 
            // button4
            // 
            button4.BackColor = Color.NavajoWhite;
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(27, 290);
            button4.Name = "button4";
            button4.Size = new Size(366, 38);
            button4.TabIndex = 88;
            button4.TabStop = false;
            button4.Text = "Добави снимка";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.BorderStyle = BorderStyle.FixedSingle;
            pictureBox4.Location = new Point(27, 31);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(366, 253);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 87;
            pictureBox4.TabStop = false;
            // 
            // button5
            // 
            button5.BackColor = Color.NavajoWhite;
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(781, 290);
            button5.Name = "button5";
            button5.Size = new Size(366, 38);
            button5.TabIndex = 90;
            button5.TabStop = false;
            button5.Text = "Добави снимка";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BorderStyle = BorderStyle.FixedSingle;
            pictureBox5.Location = new Point(781, 31);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(366, 253);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 89;
            pictureBox5.TabStop = false;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(63, 691);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 55);
            artefactsBtn.TabIndex = 91;
            artefactsBtn.TabStop = false;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsBtn_Click;
            // 
            // Images
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1218, 793);
            Controls.Add(artefactsBtn);
            Controls.Add(button5);
            Controls.Add(pictureBox5);
            Controls.Add(button4);
            Controls.Add(pictureBox4);
            Controls.Add(button3);
            Controls.Add(pictureBox3);
            Controls.Add(button2);
            Controls.Add(pictureBox2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBtn);
            Controls.Add(pictureBox);
            Name = "Images";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Images";
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox;
        private Button pictureBtn;
        private OpenFileDialog openFileDialog1;
        private Button button1;
        private PictureBox pictureBox1;
        private Button button2;
        private PictureBox pictureBox2;
        private Button button3;
        private PictureBox pictureBox3;
        private Button button4;
        private PictureBox pictureBox4;
        private Button button5;
        private PictureBox pictureBox5;
        private Button artefactsBtn;
    }
}