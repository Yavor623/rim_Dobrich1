﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class AssesmentProtocol : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        Bitmap bitmap;
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        public AssesmentProtocol()
        {
            InitializeComponent();
        }

        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.assesmentProtocolDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.assesmentProtocolDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.assesmentProtocolDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.assesmentProtocolDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.assesmentProtocolDataGrid.GridColor = Color.BlueViolet;
        }
        //Избира данните от таблицата assesmentprotocol и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT assesmentpr_id AS 'Индекс', assesmentpr_date AS 'Дата',assesmentpr_price AS 'Сума' FROM rim_dobrich.assesmentprotocol";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            assesmentProtocolDataGrid.DataSource = sqlDT;
        }

        private void AssesmentProtocol_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }

        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Sections sections = new Sections();
            sections.Show();
            assesmentProtocol.Close();
            this.Hide();

        }
        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();
            assesmentProtocol.Close();
            this.Hide();
        }

        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Materials materials = new Materials();
            materials.Show();
            assesmentProtocol.Close();
            this.Hide();
        }

        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Shapes shapes = new Shapes();
            shapes.Show();
            assesmentProtocol.Close();
            this.Hide();
        }

        private void typesbtn_Click_1(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Types types = new Types();
            types.Show();
            assesmentProtocol.Close();
            this.Hide();
        }
        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            assesmentProtocol.Close();
            this.Hide();
        }

        private void menubtn_Click_1(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Menu menu = new Menu();
            menu.Show();
            assesmentProtocol.Close();
            this.Hide();
        }



        private void addNewbtn_Click_1(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            try
            {

                sqlConn.Open();

                //Вмъква в таблицата assesmentprotocol съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.assesmentprotocol(assesmentpr_id,assesmentpr_date,assesmentpr_price) VALUES('{indexTxt.Text}','{dateOfAssesmentProtocol.Text}','{priceOfAssesmentProtocolTxt.Text}')";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();

                sqlConn.Close();
                MessageBox.Show($"Успешно добавяне на оц.протокол №{indexTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на оц.протокол №{indexTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void updatebtn_Click_1(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {

                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата assesmentprotocol 
                sqlCmd.CommandText = "UPDATE rim_dobrich.assesmentprotocol SET assesmentpr_id=@assesmentpr_id, assesmentpr_date=@assesmentpr_date, assesmentpr_price=@assesmentpr_price WHERE assesmentpr_id=@assesmentpr_id";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@assesmentpr_id", indexTxt.Text);
                sqlCmd.Parameters.AddWithValue("@assesmentpr_date", dateOfAssesmentProtocol.Text);
                sqlCmd.Parameters.AddWithValue("@assesmentpr_price", priceOfAssesmentProtocolTxt.Text);

                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяване на оц.протокол №{indexTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                UploadData();

            }
            catch (Exception elex)
            {
                MessageBox.Show($"Неуспешно обновяване на оц.протокол №{indexTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deletebtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата assesmentprotocol реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.assesmentprotocol WHERE assesmentpr_id={indexTxt.Text};";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                MessageBox.Show($"Успешно премахване на оц.протокол №{indexTxt.Text}", "", MessageBoxButtons.OK);
                foreach (DataGridViewRow item in this.assesmentProtocolDataGrid.SelectedRows)
                {
                    assesmentProtocolDataGrid.Rows.RemoveAt(item.Index);

                }
                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно премахване на оц.протокол №{indexTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void typesDataGrid_CellClick_1(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                indexTxt.Text = assesmentProtocolDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                dateOfAssesmentProtocol.Text = assesmentProtocolDataGrid.SelectedRows[0].Cells[1].Value.ToString();
                priceOfAssesmentProtocolTxt.Text = assesmentProtocolDataGrid.SelectedRows[0].Cells[2].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void collectionsBtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            CollectionsMuseum collections = new CollectionsMuseum();
            collections.Show();
            assesmentProtocol.Close();
            this.Hide();
        }
        private void queriesbtn_Click(object sender, EventArgs e)  //Затваря сегашния формуляр и отваря формуляра Queries
        {
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            Queries queries = new Queries();
            queries.Show();
            assesmentProtocol.Close();
            this.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Връща началните стойности, занулира
            indexTxt.Text = string.Empty;
            dateOfAssesmentProtocol.Text = string.Empty;
            priceOfAssesmentProtocolTxt.Text = string.Empty;
        }

        private void indexTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void priceOfAssesmentProtocolTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }
    }
}
