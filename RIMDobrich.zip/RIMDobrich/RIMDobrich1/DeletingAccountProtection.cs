﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace RIMDobrich1
{
    public partial class DeletingAccountProtection : Form
    {
        public string DirectorPassword { get; set; }
        public string Username { get; set; }
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        public DeletingAccountProtection(string directorPassword, string username)
        {
            this.DirectorPassword = directorPassword;
            this.Username = username;
            InitializeComponent();
        }
        public DeletingAccountProtection()
        {
            InitializeComponent();
        }

        private void deleteAccountReadyButton_Click(object sender, EventArgs e)
        {
            if (DirectorPassword == passwordTextBox.Text)
            {
                try
                {
                    sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                    sqlConn.Open();
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandText = $"DELETE FROM Users WHERE username = '{Username}'";

                    MySqlDataReader reader = sqlCmd.ExecuteReader();

                    sqlConn.Close();

                    MessageBox.Show("Успешно премахване на акаунт");
                    DeletingAccountProtection deletingAccountProtection = new DeletingAccountProtection();
                    this.Hide();
                    deletingAccountProtection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }
    }
}
