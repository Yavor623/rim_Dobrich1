﻿namespace RIMDobrich1
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            firstNameTextBox = new TextBox();
            lastNameTextBox = new TextBox();
            passwordTextBox = new TextBox();
            usernameTextBox = new TextBox();
            emailTextBox = new TextBox();
            dateOfBirth = new DateTimePicker();
            privilegesComboBox = new ComboBox();
            firstNameLabel = new Label();
            lastNameLabel = new Label();
            usernameLabel = new Label();
            passwordLabel = new Label();
            privilegesLabel = new Label();
            emailLabel = new Label();
            dateOfBirthLabel = new Label();
            createAccountButton = new Button();
            passwordCheckBox = new CheckBox();
            directorMenuLabel = new Label();
            nameOfMuseumComboBox = new ComboBox();
            nameOfMuseumLabel = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            directorMenuLinkLabel = new LinkLabel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // firstNameTextBox
            // 
            firstNameTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            firstNameTextBox.Location = new Point(3, 43);
            firstNameTextBox.Multiline = true;
            firstNameTextBox.Name = "firstNameTextBox";
            firstNameTextBox.Size = new Size(636, 34);
            firstNameTextBox.TabIndex = 0;
            firstNameTextBox.TabStop = false;
            // 
            // lastNameTextBox
            // 
            lastNameTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            lastNameTextBox.Location = new Point(3, 123);
            lastNameTextBox.Multiline = true;
            lastNameTextBox.Name = "lastNameTextBox";
            lastNameTextBox.Size = new Size(636, 34);
            lastNameTextBox.TabIndex = 1;
            lastNameTextBox.TabStop = false;
            // 
            // passwordTextBox
            // 
            passwordTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            passwordTextBox.Location = new Point(3, 283);
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PasswordChar = '*';
            passwordTextBox.Size = new Size(636, 34);
            passwordTextBox.TabIndex = 2;
            passwordTextBox.TabStop = false;
            // 
            // usernameTextBox
            // 
            usernameTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            usernameTextBox.Location = new Point(3, 203);
            usernameTextBox.Multiline = true;
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(636, 34);
            usernameTextBox.TabIndex = 3;
            usernameTextBox.TabStop = false;
            // 
            // emailTextBox
            // 
            emailTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            emailTextBox.Location = new Point(3, 483);
            emailTextBox.Multiline = true;
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(636, 34);
            emailTextBox.TabIndex = 4;
            emailTextBox.TabStop = false;
            // 
            // dateOfBirth
            // 
            dateOfBirth.CustomFormat = "yyyy-MM-dd";
            dateOfBirth.Font = new Font("Cambria", 13F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfBirth.Format = DateTimePickerFormat.Custom;
            dateOfBirth.Location = new Point(3, 563);
            dateOfBirth.Name = "dateOfBirth";
            dateOfBirth.Size = new Size(636, 33);
            dateOfBirth.TabIndex = 5;
            dateOfBirth.TabStop = false;
            // 
            // privilegesComboBox
            // 
            privilegesComboBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            privilegesComboBox.FormattingEnabled = true;
            privilegesComboBox.Location = new Point(3, 403);
            privilegesComboBox.Name = "privilegesComboBox";
            privilegesComboBox.Size = new Size(636, 38);
            privilegesComboBox.TabIndex = 6;
            privilegesComboBox.TabStop = false;
            // 
            // firstNameLabel
            // 
            firstNameLabel.AutoSize = true;
            firstNameLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            firstNameLabel.Location = new Point(3, 0);
            firstNameLabel.Name = "firstNameLabel";
            firstNameLabel.Size = new Size(63, 28);
            firstNameLabel.TabIndex = 7;
            firstNameLabel.Text = "Име:";
            // 
            // lastNameLabel
            // 
            lastNameLabel.AutoSize = true;
            lastNameLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lastNameLabel.Location = new Point(3, 80);
            lastNameLabel.Name = "lastNameLabel";
            lastNameLabel.Size = new Size(119, 28);
            lastNameLabel.TabIndex = 8;
            lastNameLabel.Text = "Фамилия:";
            // 
            // usernameLabel
            // 
            usernameLabel.AutoSize = true;
            usernameLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            usernameLabel.Location = new Point(3, 160);
            usernameLabel.Name = "usernameLabel";
            usernameLabel.Size = new Size(232, 28);
            usernameLabel.TabIndex = 9;
            usernameLabel.Text = "Потребителско име:";
            // 
            // passwordLabel
            // 
            passwordLabel.AutoSize = true;
            passwordLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            passwordLabel.Location = new Point(3, 240);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new Size(97, 28);
            passwordLabel.TabIndex = 10;
            passwordLabel.Text = "Парола:";
            // 
            // privilegesLabel
            // 
            privilegesLabel.AutoSize = true;
            privilegesLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            privilegesLabel.Location = new Point(3, 360);
            privilegesLabel.Name = "privilegesLabel";
            privilegesLabel.Size = new Size(151, 28);
            privilegesLabel.TabIndex = 11;
            privilegesLabel.Text = "Привилегия:";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            emailLabel.Location = new Point(3, 440);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(86, 28);
            emailLabel.TabIndex = 12;
            emailLabel.Text = "E-mail:";
            // 
            // dateOfBirthLabel
            // 
            dateOfBirthLabel.AutoSize = true;
            dateOfBirthLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfBirthLabel.Location = new Point(3, 520);
            dateOfBirthLabel.Name = "dateOfBirthLabel";
            dateOfBirthLabel.Size = new Size(199, 28);
            dateOfBirthLabel.TabIndex = 13;
            dateOfBirthLabel.Text = "Дата на раждане:";
            // 
            // createAccountButton
            // 
            createAccountButton.BackColor = Color.NavajoWhite;
            createAccountButton.Dock = DockStyle.Bottom;
            createAccountButton.FlatAppearance.BorderSize = 0;
            createAccountButton.FlatStyle = FlatStyle.Flat;
            createAccountButton.Font = new Font("Cambria", 15F, FontStyle.Regular, GraphicsUnit.Point);
            createAccountButton.Location = new Point(3, 715);
            createAccountButton.Name = "createAccountButton";
            createAccountButton.Size = new Size(636, 41);
            createAccountButton.TabIndex = 16;
            createAccountButton.TabStop = false;
            createAccountButton.Text = "Създаване";
            createAccountButton.UseVisualStyleBackColor = false;
            createAccountButton.Click += registrationButton_Click;
            // 
            // passwordCheckBox
            // 
            passwordCheckBox.AutoSize = true;
            passwordCheckBox.Dock = DockStyle.Right;
            passwordCheckBox.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            passwordCheckBox.Location = new Point(438, 323);
            passwordCheckBox.Name = "passwordCheckBox";
            passwordCheckBox.Size = new Size(201, 34);
            passwordCheckBox.TabIndex = 17;
            passwordCheckBox.TabStop = false;
            passwordCheckBox.Text = "Покажи парола";
            passwordCheckBox.UseVisualStyleBackColor = true;
            passwordCheckBox.CheckedChanged += passwordCheckBox_CheckedChanged;
            // 
            // directorMenuLabel
            // 
            directorMenuLabel.AutoSize = true;
            directorMenuLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            directorMenuLabel.Location = new Point(3, 759);
            directorMenuLabel.Name = "directorMenuLabel";
            directorMenuLabel.Size = new Size(619, 28);
            directorMenuLabel.TabIndex = 18;
            directorMenuLabel.Text = "Ако искаш да се върнеш в главното меню за директори,";
            // 
            // nameOfMuseumComboBox
            // 
            nameOfMuseumComboBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumComboBox.FormattingEnabled = true;
            nameOfMuseumComboBox.Location = new Point(3, 643);
            nameOfMuseumComboBox.Name = "nameOfMuseumComboBox";
            nameOfMuseumComboBox.Size = new Size(636, 38);
            nameOfMuseumComboBox.TabIndex = 20;
            nameOfMuseumComboBox.TabStop = false;
            // 
            // nameOfMuseumLabel
            // 
            nameOfMuseumLabel.AutoSize = true;
            nameOfMuseumLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumLabel.Location = new Point(3, 600);
            nameOfMuseumLabel.Name = "nameOfMuseumLabel";
            nameOfMuseumLabel.Size = new Size(87, 28);
            nameOfMuseumLabel.TabIndex = 21;
            nameOfMuseumLabel.Text = "Музей:";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.99854F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.0014572F));
            tableLayoutPanel1.Controls.Add(nameOfMuseumComboBox, 0, 16);
            tableLayoutPanel1.Controls.Add(nameOfMuseumLabel, 0, 15);
            tableLayoutPanel1.Controls.Add(firstNameLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(firstNameTextBox, 0, 1);
            tableLayoutPanel1.Controls.Add(lastNameLabel, 0, 2);
            tableLayoutPanel1.Controls.Add(lastNameTextBox, 0, 3);
            tableLayoutPanel1.Controls.Add(passwordCheckBox, 0, 8);
            tableLayoutPanel1.Controls.Add(dateOfBirth, 0, 14);
            tableLayoutPanel1.Controls.Add(dateOfBirthLabel, 0, 13);
            tableLayoutPanel1.Controls.Add(usernameLabel, 0, 4);
            tableLayoutPanel1.Controls.Add(emailLabel, 0, 11);
            tableLayoutPanel1.Controls.Add(emailTextBox, 0, 12);
            tableLayoutPanel1.Controls.Add(usernameTextBox, 0, 5);
            tableLayoutPanel1.Controls.Add(privilegesComboBox, 0, 10);
            tableLayoutPanel1.Controls.Add(privilegesLabel, 0, 9);
            tableLayoutPanel1.Controls.Add(passwordLabel, 0, 6);
            tableLayoutPanel1.Controls.Add(passwordTextBox, 0, 7);
            tableLayoutPanel1.Controls.Add(createAccountButton, 0, 17);
            tableLayoutPanel1.Controls.Add(directorMenuLabel, 0, 18);
            tableLayoutPanel1.Controls.Add(directorMenuLinkLabel, 1, 18);
            tableLayoutPanel1.Location = new Point(116, 34);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 19;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253128F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 9.774436F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.01253176F));
            tableLayoutPanel1.Size = new Size(793, 810);
            tableLayoutPanel1.TabIndex = 22;
            // 
            // directorMenuLinkLabel
            // 
            directorMenuLinkLabel.AutoSize = true;
            directorMenuLinkLabel.Font = new Font("Cambria", 14F, FontStyle.Regular, GraphicsUnit.Point);
            directorMenuLinkLabel.Location = new Point(645, 759);
            directorMenuLinkLabel.Name = "directorMenuLinkLabel";
            directorMenuLinkLabel.Size = new Size(135, 28);
            directorMenuLinkLabel.TabIndex = 22;
            directorMenuLinkLabel.TabStop = true;
            directorMenuLinkLabel.Text = "кликни тук";
            directorMenuLinkLabel.LinkClicked += directorMenuLinkLabel_LinkClicked;
            // 
            // CreateAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1013, 856);
            Controls.Add(tableLayoutPanel1);
            ForeColor = Color.Black;
            MaximizeBox = false;
            MinimumSize = new Size(1031, 903);
            Name = "CreateAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Създаване на акаунт";
            Load += CreateAccount_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox firstNameTextBox;
        private TextBox lastNameTextBox;
        private TextBox passwordTextBox;
        private TextBox usernameTextBox;
        private TextBox emailTextBox;
        private DateTimePicker dateOfBirth;
        private ComboBox privilegesComboBox;
        private Label firstNameLabel;
        private Label lastNameLabel;
        private Label usernameLabel;
        private Label passwordLabel;
        private Label privilegesLabel;
        private Label emailLabel;
        private Label dateOfBirthLabel;
        private Button createAccountButton;
        private CheckBox passwordCheckBox;
        private Label directorMenuLabel;
        private ComboBox nameOfMuseumComboBox;
        private Label nameOfMuseumLabel;
        private TableLayoutPanel tableLayoutPanel1;
        private LinkLabel directorMenuLinkLabel;
    }
}