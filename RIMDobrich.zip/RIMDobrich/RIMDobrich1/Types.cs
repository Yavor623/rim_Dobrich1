﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class Types : Form
    {

        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataReader sqlRd;
        public Types()
        {
            InitializeComponent();
        }
        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.typesDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.typesDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.typesDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.typesDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.typesDataGrid.GridColor = Color.BlueViolet;
        }
        //Избира данните от таблицата types и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT type_id AS 'Индекс', type_name AS 'Име' FROM rim_dobrich.types";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            typesDataGrid.DataSource = sqlDT;
        }

        private void Types_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }


        private void searchbtn_Click_1(object sender, EventArgs e) //Търси по името на вида
        {
            try
            {
                DataView dv = sqlDT.DefaultView;
                dv.RowFilter = string.Format("Име like'%{0}%'", searchTxt.Text);
                typesDataGrid.DataSource = dv.ToTable();
                UploadData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addNewbtn_Click_1(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            try
            {
                sqlConn.Open();

                //Вмъква в таблицата types съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.types(type_id,type_name) VALUES('{indexTxt.Text}','{typeNameTxt.Text}')";

                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();

                sqlConn.Close();

                MessageBox.Show($"Успешно добавяне на {typeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                typeNameTxt.Text = string.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {typeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void updatebtn_Click_1(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {
                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата types 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.types SET type_name=@type_name WHERE type_id={indexTxt.Text}";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@type_name", typeNameTxt.Text);

                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяване на {typeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                typeNameTxt.Text = string.Empty;

                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {typeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deletebtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата types реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.types WHERE type_id={indexTxt.Text};";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                foreach (DataGridViewRow item in this.typesDataGrid.SelectedRows)
                {
                    typesDataGrid.Rows.RemoveAt(item.Index);

                }
                MessageBox.Show($"Успешно изтриване на {typeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                typeNameTxt.Text = string.Empty;

                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изтриване на {typeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void typesDataGrid_CellClick_1(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                indexTxt.Text = typesDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                typeNameTxt.Text = typesDataGrid.SelectedRows[0].Cells[1].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Types types = new Types();
            Sections sections = new Sections();
            sections.Show();
            types.Close();
            this.Hide();
        }

        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Types types = new Types();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            types.Close();
            this.Hide();
        }

        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Types types = new Types();
            Menu menu = new Menu();
            menu.Show();

            types.Close();
            this.Hide();
        }

        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Types types = new Types();
            Shapes description = new Shapes();
            description.Show();
            types.Close();
            this.Hide();
        }

        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {
            Types types = new Types();
            Materials materials = new Materials();
            materials.Show();
            types.Close();
            this.Hide();
        }

        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            Types types = new Types();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();
            types.Close();
            this.Hide();
        }

        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            Types types = new Types();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            types.Close();
            this.Hide();
        }

        private void collectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Types types = new Types();
            CollectionsMuseum collectionsMuseum = new CollectionsMuseum();
            collectionsMuseum.Show();
            types.Close();
            this.Hide();
        }
        private void queriesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Types types = new Types();
            Queries queries = new Queries();
            queries.Show();
            types.Close();
            this.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Връща началните стойности, занулира
            indexTxt.Text = string.Empty;
            typeNameTxt.Text = string.Empty;
        }

        private void indexTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }
    }
}
