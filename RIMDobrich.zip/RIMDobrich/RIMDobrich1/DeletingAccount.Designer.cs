﻿namespace RIMDobrich1
{
    partial class DeletingAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            usernameLabel = new Label();
            usernameTextBox = new TextBox();
            deleteAccountButton = new Button();
            directorMenuLabel = new Label();
            directorMenuLinkLabel = new LinkLabel();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(385, -3);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 25;
            // 
            // usernameLabel
            // 
            usernameLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            usernameLabel.AutoSize = true;
            usernameLabel.Font = new Font("Cambria", 15F, FontStyle.Regular, GraphicsUnit.Point);
            usernameLabel.Location = new Point(3, 87);
            usernameLabel.Name = "usernameLabel";
            usernameLabel.Size = new Size(245, 30);
            usernameLabel.TabIndex = 22;
            usernameLabel.Text = "Потребителско име:";
            // 
            // usernameTextBox
            // 
            usernameTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            usernameTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            usernameTextBox.Location = new Point(3, 180);
            usernameTextBox.MaxLength = 40;
            usernameTextBox.Multiline = true;
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(581, 51);
            usernameTextBox.TabIndex = 20;
            usernameTextBox.TabStop = false;
            // 
            // deleteAccountButton
            // 
            deleteAccountButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteAccountButton.BackColor = Color.NavajoWhite;
            deleteAccountButton.FlatAppearance.BorderSize = 0;
            deleteAccountButton.FlatStyle = FlatStyle.Flat;
            deleteAccountButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            deleteAccountButton.Location = new Point(3, 288);
            deleteAccountButton.Name = "deleteAccountButton";
            deleteAccountButton.Size = new Size(581, 60);
            deleteAccountButton.TabIndex = 24;
            deleteAccountButton.TabStop = false;
            deleteAccountButton.Text = "Премахни";
            deleteAccountButton.UseVisualStyleBackColor = false;
            deleteAccountButton.Click += logInButton_Click;
            // 
            // directorMenuLabel
            // 
            directorMenuLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            directorMenuLabel.AutoSize = true;
            directorMenuLabel.Font = new Font("Cambria", 13F, FontStyle.Regular, GraphicsUnit.Point);
            directorMenuLabel.Location = new Point(3, 445);
            directorMenuLabel.Name = "directorMenuLabel";
            directorMenuLabel.Size = new Size(577, 26);
            directorMenuLabel.TabIndex = 26;
            directorMenuLabel.Text = "Ако искаш да се върнеш в главното меню за директори,";
            // 
            // directorMenuLinkLabel
            // 
            directorMenuLinkLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            directorMenuLinkLabel.AutoSize = true;
            directorMenuLinkLabel.Font = new Font("Cambria", 13F, FontStyle.Regular, GraphicsUnit.Point);
            directorMenuLinkLabel.Location = new Point(590, 445);
            directorMenuLinkLabel.Name = "directorMenuLinkLabel";
            directorMenuLinkLabel.Size = new Size(126, 26);
            directorMenuLinkLabel.TabIndex = 27;
            directorMenuLinkLabel.TabStop = true;
            directorMenuLinkLabel.Text = "кликни тук";
            directorMenuLinkLabel.LinkClicked += directorMenuLinkLabel_LinkClicked;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Controls.Add(directorMenuLinkLabel, 1, 3);
            tableLayoutPanel1.Controls.Add(usernameLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(directorMenuLabel, 0, 3);
            tableLayoutPanel1.Controls.Add(usernameTextBox, 0, 1);
            tableLayoutPanel1.Controls.Add(deleteAccountButton, 0, 2);
            tableLayoutPanel1.Location = new Point(154, 138);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Size = new Size(734, 471);
            tableLayoutPanel1.TabIndex = 28;
            // 
            // DeletingAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1013, 753);
            Controls.Add(label1);
            Controls.Add(tableLayoutPanel1);
            ForeColor = SystemColors.ControlText;
            MinimumSize = new Size(1031, 800);
            Name = "DeletingAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Премахване на акаунт";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label usernameLabel;
        private TextBox usernameTextBox;
        private Button deleteAccountButton;
        private Label directorMenuLabel;
        private LinkLabel directorMenuLinkLabel;
        private TableLayoutPanel tableLayoutPanel1;
    }
}