﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace RIMDobrich1
{
    public partial class SignInForm : Form
    {
        string directorPassword = "";
        int sectionId;
        int privileges;

        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        public SignInForm()
        {
            InitializeComponent();
        }

        private void logInButton_Click(object sender, EventArgs e)
        {
            string userPassword = "";
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = $"SELECT password,privilegeId,section_id FROM Users WHERE username = '{usernameTextBox.Text}'";

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                userPassword = reader.GetString("password");
                privileges = reader.GetInt32("privilegeId");
                sectionId = reader.GetInt32("section_id");
            }

            sqlConn.Close();


            if (userPassword == passwordTextBox.Text)
            {
                if (privileges == 1|| privileges == 2)
                {
                    directorPassword = passwordTextBox.Text;
                    MessageBox.Show("Успешно влизане");
                    SignInForm signInForm = new SignInForm();
                    DirectorMenu directorMenu = new DirectorMenu(directorPassword);
                    directorMenu.Show();
                    this.Hide();
                    signInForm.Close();
                }
                else if (privileges == 5)
                {
                    MessageBox.Show("Успешно влизане");
                    SignInForm signInForm = new SignInForm();
                    Restoration restoration = new Restoration();
                    restoration.Show();
                    this.Hide();
                    signInForm.Close();
                }
                else
                {
                    MessageBox.Show("Успешно влизане");
                    SignInForm signInForm1 = new SignInForm();
                    Artefacts artefacts = new Artefacts(sectionId, privileges);
                    artefacts.Show();
                    this.Hide();
                    signInForm1.Close();
                }

            }
            else
            {
                MessageBox.Show("Грешнo потребителско име или парола");
            }
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {

            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }

        private void usernameTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }

        }
    }
}
