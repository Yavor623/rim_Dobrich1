﻿namespace RIMDobrich1
{
    partial class Restoration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inventoryId = new TextBox();
            size = new TextBox();
            reasonsForEntry = new TextBox();
            protocoloftheconservationcouncill = new TextBox();
            origin = new TextBox();
            property = new TextBox();
            reportsofpastconservation = new TextBox();
            dating = new TextBox();
            descriptionoftheconservation = new TextBox();
            descriptionoftheitem = new TextBox();
            beforePicture = new PictureBox();
            afterPicture = new PictureBox();
            beforePictureLabel = new Label();
            afterPictureLabel = new Label();
            beforePictureBtn = new Button();
            afterPictureBtn = new Button();
            dateOfEntry = new DateTimePicker();
            protocoloftheconservationcouncilwithwhichitwasaccepted = new TextBox();
            recommendationforconservation = new TextBox();
            materialComboBox = new ComboBox();
            searchBtn = new Button();
            searchTxt = new TextBox();
            restorationDataGrid = new DataGridView();
            addNewBtn = new Button();
            deleteBtn = new Button();
            updateBtn = new Button();
            resetBtn = new Button();
            openBeforePicture = new OpenFileDialog();
            openAfterPicture = new OpenFileDialog();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)beforePicture).BeginInit();
            ((System.ComponentModel.ISupportInitialize)afterPicture).BeginInit();
            ((System.ComponentModel.ISupportInitialize)restorationDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // inventoryId
            // 
            inventoryId.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            inventoryId.Location = new Point(3, 3);
            inventoryId.Multiline = true;
            inventoryId.Name = "inventoryId";
            inventoryId.PlaceholderText = "Инвентарен номер";
            inventoryId.Size = new Size(447, 40);
            inventoryId.TabIndex = 0;
            // 
            // size
            // 
            size.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            size.Location = new Point(456, 141);
            size.Multiline = true;
            size.Name = "size";
            size.PlaceholderText = "Размери";
            size.Size = new Size(447, 40);
            size.TabIndex = 1;
            // 
            // reasonsForEntry
            // 
            reasonsForEntry.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            reasonsForEntry.Location = new Point(456, 210);
            reasonsForEntry.Multiline = true;
            reasonsForEntry.Name = "reasonsForEntry";
            reasonsForEntry.PlaceholderText = "Причини за постъпване";
            reasonsForEntry.Size = new Size(447, 40);
            reasonsForEntry.TabIndex = 2;
            // 
            // protocoloftheconservationcouncill
            // 
            protocoloftheconservationcouncill.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            protocoloftheconservationcouncill.Location = new Point(456, 279);
            protocoloftheconservationcouncill.Multiline = true;
            protocoloftheconservationcouncill.Name = "protocoloftheconservationcouncill";
            protocoloftheconservationcouncill.PlaceholderText = "Протокол на консерв. съвет, с който е одобрено предложението";
            protocoloftheconservationcouncill.Size = new Size(447, 40);
            protocoloftheconservationcouncill.TabIndex = 3;
            // 
            // origin
            // 
            origin.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            origin.Location = new Point(3, 72);
            origin.Multiline = true;
            origin.Name = "origin";
            origin.PlaceholderText = "Произход";
            origin.Size = new Size(447, 40);
            origin.TabIndex = 4;
            // 
            // property
            // 
            property.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            property.Location = new Point(456, 3);
            property.Multiline = true;
            property.Name = "property";
            property.PlaceholderText = "Собственост";
            property.Size = new Size(447, 40);
            property.TabIndex = 6;
            // 
            // reportsofpastconservation
            // 
            reportsofpastconservation.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            reportsofpastconservation.Location = new Point(3, 279);
            reportsofpastconservation.Multiline = true;
            reportsofpastconservation.Name = "reportsofpastconservation";
            reportsofpastconservation.PlaceholderText = "Сведения за предшестващи консерв. и др. намеси";
            reportsofpastconservation.Size = new Size(447, 40);
            reportsofpastconservation.TabIndex = 7;
            // 
            // dating
            // 
            dating.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            dating.Location = new Point(3, 141);
            dating.Multiline = true;
            dating.Name = "dating";
            dating.PlaceholderText = "Датировка";
            dating.Size = new Size(447, 40);
            dating.TabIndex = 9;
            // 
            // descriptionoftheconservation
            // 
            descriptionoftheconservation.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            descriptionoftheconservation.Location = new Point(456, 348);
            descriptionoftheconservation.Multiline = true;
            descriptionoftheconservation.Name = "descriptionoftheconservation";
            descriptionoftheconservation.PlaceholderText = "Описание на консерв. и реставр. работа";
            descriptionoftheconservation.Size = new Size(447, 40);
            descriptionoftheconservation.TabIndex = 10;
            // 
            // descriptionoftheitem
            // 
            descriptionoftheitem.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            descriptionoftheitem.Location = new Point(3, 348);
            descriptionoftheitem.Multiline = true;
            descriptionoftheitem.Name = "descriptionoftheitem";
            descriptionoftheitem.PlaceholderText = "Описание на муз. предмет преди започване на обработка ";
            descriptionoftheitem.Size = new Size(447, 40);
            descriptionoftheitem.TabIndex = 11;
            // 
            // beforePicture
            // 
            beforePicture.Location = new Point(3, 639);
            beforePicture.Name = "beforePicture";
            tableLayoutPanel1.SetRowSpan(beforePicture, 3);
            beforePicture.Size = new Size(435, 201);
            beforePicture.SizeMode = PictureBoxSizeMode.Zoom;
            beforePicture.TabIndex = 12;
            beforePicture.TabStop = false;
            // 
            // afterPicture
            // 
            afterPicture.Location = new Point(456, 639);
            afterPicture.Name = "afterPicture";
            tableLayoutPanel1.SetRowSpan(afterPicture, 3);
            afterPicture.Size = new Size(430, 201);
            afterPicture.SizeMode = PictureBoxSizeMode.Zoom;
            afterPicture.TabIndex = 13;
            afterPicture.TabStop = false;
            // 
            // beforePictureLabel
            // 
            beforePictureLabel.AutoSize = true;
            beforePictureLabel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            beforePictureLabel.Location = new Point(3, 594);
            beforePictureLabel.Name = "beforePictureLabel";
            beforePictureLabel.Size = new Size(177, 35);
            beforePictureLabel.TabIndex = 14;
            beforePictureLabel.Text = "снимка преди";
            // 
            // afterPictureLabel
            // 
            afterPictureLabel.AutoSize = true;
            afterPictureLabel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            afterPictureLabel.Location = new Point(456, 594);
            afterPictureLabel.Name = "afterPictureLabel";
            afterPictureLabel.Size = new Size(158, 35);
            afterPictureLabel.TabIndex = 15;
            afterPictureLabel.Text = "снимка след";
            // 
            // beforePictureBtn
            // 
            beforePictureBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            beforePictureBtn.BackColor = Color.NavajoWhite;
            beforePictureBtn.Cursor = Cursors.Hand;
            beforePictureBtn.FlatStyle = FlatStyle.Flat;
            beforePictureBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            beforePictureBtn.Location = new Point(3, 857);
            beforePictureBtn.Name = "beforePictureBtn";
            beforePictureBtn.Size = new Size(447, 56);
            beforePictureBtn.TabIndex = 80;
            beforePictureBtn.TabStop = false;
            beforePictureBtn.Text = "Добави снимка";
            beforePictureBtn.UseVisualStyleBackColor = false;
            beforePictureBtn.Click += beforePictureBtn_Click;
            // 
            // afterPictureBtn
            // 
            afterPictureBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            afterPictureBtn.BackColor = Color.NavajoWhite;
            afterPictureBtn.Cursor = Cursors.Hand;
            afterPictureBtn.FlatStyle = FlatStyle.Flat;
            afterPictureBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            afterPictureBtn.Location = new Point(456, 857);
            afterPictureBtn.Name = "afterPictureBtn";
            afterPictureBtn.Size = new Size(447, 56);
            afterPictureBtn.TabIndex = 81;
            afterPictureBtn.TabStop = false;
            afterPictureBtn.Text = "Добави снимка";
            afterPictureBtn.UseVisualStyleBackColor = false;
            afterPictureBtn.Click += afterPictureBtn_Click;
            // 
            // dateOfEntry
            // 
            dateOfEntry.CustomFormat = "yyyy-MM-dd";
            dateOfEntry.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfEntry.Format = DateTimePickerFormat.Custom;
            dateOfEntry.Location = new Point(456, 72);
            dateOfEntry.Name = "dateOfEntry";
            dateOfEntry.Size = new Size(447, 41);
            dateOfEntry.TabIndex = 82;
            // 
            // protocoloftheconservationcouncilwithwhichitwasaccepted
            // 
            protocoloftheconservationcouncilwithwhichitwasaccepted.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            protocoloftheconservationcouncilwithwhichitwasaccepted.Location = new Point(3, 417);
            protocoloftheconservationcouncilwithwhichitwasaccepted.Multiline = true;
            protocoloftheconservationcouncilwithwhichitwasaccepted.Name = "protocoloftheconservationcouncilwithwhichitwasaccepted";
            protocoloftheconservationcouncilwithwhichitwasaccepted.PlaceholderText = "Протокол на консерв. съвет, с който е приета обработка на ДПК ";
            protocoloftheconservationcouncilwithwhichitwasaccepted.Size = new Size(447, 40);
            protocoloftheconservationcouncilwithwhichitwasaccepted.TabIndex = 84;
            // 
            // recommendationforconservation
            // 
            recommendationforconservation.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            recommendationforconservation.Location = new Point(456, 417);
            recommendationforconservation.Multiline = true;
            recommendationforconservation.Name = "recommendationforconservation";
            recommendationforconservation.PlaceholderText = "Препоръки са съхраняване";
            recommendationforconservation.Size = new Size(447, 40);
            recommendationforconservation.TabIndex = 83;
            // 
            // materialComboBox
            // 
            materialComboBox.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            materialComboBox.FormattingEnabled = true;
            materialComboBox.Location = new Point(3, 210);
            materialComboBox.Name = "materialComboBox";
            materialComboBox.Size = new Size(447, 43);
            materialComboBox.TabIndex = 85;
            materialComboBox.Text = "Материал";
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.NavajoWhite;
            searchBtn.Cursor = Cursors.Hand;
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            searchBtn.Location = new Point(3, 528);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(447, 37);
            searchBtn.TabIndex = 102;
            searchBtn.TabStop = false;
            searchBtn.Text = "Търси";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchBtn_Click;
            // 
            // searchTxt
            // 
            searchTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(3, 486);
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търси по инв. номер";
            searchTxt.Size = new Size(447, 35);
            searchTxt.TabIndex = 101;
            searchTxt.TabStop = false;
            // 
            // restorationDataGrid
            // 
            restorationDataGrid.AllowUserToAddRows = false;
            restorationDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            restorationDataGrid.BackgroundColor = Color.Tan;
            restorationDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            restorationDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(restorationDataGrid, 2);
            restorationDataGrid.Cursor = Cursors.PanNW;
            restorationDataGrid.Location = new Point(909, 3);
            restorationDataGrid.MultiSelect = false;
            restorationDataGrid.Name = "restorationDataGrid";
            restorationDataGrid.ReadOnly = true;
            restorationDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(restorationDataGrid, 12);
            restorationDataGrid.RowTemplate.Height = 29;
            restorationDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            restorationDataGrid.Size = new Size(902, 768);
            restorationDataGrid.TabIndex = 103;
            restorationDataGrid.TabStop = false;
            restorationDataGrid.CellClick += restorationDataGrid_CellClick;
            // 
            // addNewBtn
            // 
            addNewBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            addNewBtn.BackColor = Color.NavajoWhite;
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(909, 795);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(447, 45);
            addNewBtn.TabIndex = 104;
            addNewBtn.TabStop = false;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewBtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteBtn.BackColor = Color.NavajoWhite;
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(909, 867);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(447, 46);
            deleteBtn.TabIndex = 105;
            deleteBtn.TabStop = false;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // updateBtn
            // 
            updateBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            updateBtn.BackColor = Color.NavajoWhite;
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(1362, 797);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(449, 43);
            updateBtn.TabIndex = 106;
            updateBtn.TabStop = false;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updateBtn_Click;
            // 
            // resetBtn
            // 
            resetBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            resetBtn.BackColor = Color.NavajoWhite;
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(1362, 867);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(449, 46);
            resetBtn.TabIndex = 107;
            resetBtn.TabStop = false;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(inventoryId, 0, 0);
            tableLayoutPanel1.Controls.Add(property, 1, 0);
            tableLayoutPanel1.Controls.Add(restorationDataGrid, 2, 0);
            tableLayoutPanel1.Controls.Add(origin, 0, 1);
            tableLayoutPanel1.Controls.Add(dating, 0, 2);
            tableLayoutPanel1.Controls.Add(afterPicture, 1, 10);
            tableLayoutPanel1.Controls.Add(recommendationforconservation, 1, 6);
            tableLayoutPanel1.Controls.Add(descriptionoftheconservation, 1, 5);
            tableLayoutPanel1.Controls.Add(reportsofpastconservation, 0, 4);
            tableLayoutPanel1.Controls.Add(protocoloftheconservationcouncill, 1, 4);
            tableLayoutPanel1.Controls.Add(descriptionoftheitem, 0, 5);
            tableLayoutPanel1.Controls.Add(searchBtn, 0, 8);
            tableLayoutPanel1.Controls.Add(beforePictureLabel, 0, 9);
            tableLayoutPanel1.Controls.Add(beforePicture, 0, 10);
            tableLayoutPanel1.Controls.Add(materialComboBox, 0, 3);
            tableLayoutPanel1.Controls.Add(size, 1, 2);
            tableLayoutPanel1.Controls.Add(reasonsForEntry, 1, 3);
            tableLayoutPanel1.Controls.Add(afterPictureLabel, 1, 9);
            tableLayoutPanel1.Controls.Add(dateOfEntry, 1, 1);
            tableLayoutPanel1.Controls.Add(protocoloftheconservationcouncilwithwhichitwasaccepted, 0, 6);
            tableLayoutPanel1.Controls.Add(searchTxt, 0, 7);
            tableLayoutPanel1.Controls.Add(beforePictureBtn, 0, 13);
            tableLayoutPanel1.Controls.Add(afterPictureBtn, 1, 13);
            tableLayoutPanel1.Controls.Add(deleteBtn, 2, 13);
            tableLayoutPanel1.Controls.Add(resetBtn, 3, 13);
            tableLayoutPanel1.Controls.Add(updateBtn, 3, 12);
            tableLayoutPanel1.Controls.Add(addNewBtn, 2, 12);
            tableLayoutPanel1.Location = new Point(44, 38);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 14;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.58836269F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.59447145F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.568097F));
            tableLayoutPanel1.Size = new Size(1814, 916);
            tableLayoutPanel1.TabIndex = 108;
            // 
            // Restoration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            MinimumSize = new Size(1500, 724);
            Name = "Restoration";
            Text = "Restoration";
            Load += Restoration_Load;
            ((System.ComponentModel.ISupportInitialize)beforePicture).EndInit();
            ((System.ComponentModel.ISupportInitialize)afterPicture).EndInit();
            ((System.ComponentModel.ISupportInitialize)restorationDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox inventoryId;
        private TextBox size;
        private TextBox reasonsForEntry;
        private TextBox protocoloftheconservationcouncill;
        private TextBox origin;
        private TextBox property;
        private TextBox reportsofpastconservation;
        private TextBox dating;
        private TextBox descriptionoftheconservation;
        private TextBox descriptionoftheitem;
        private PictureBox beforePicture;
        private PictureBox afterPicture;
        private Label beforePictureLabel;
        private Label afterPictureLabel;
        private Button beforePictureBtn;
        private Button afterPictureBtn;
        private DateTimePicker dateOfEntry;
        private TextBox protocoloftheconservationcouncilwithwhichitwasaccepted;
        private TextBox recommendationforconservation;
        private ComboBox materialComboBox;
        private Button searchBtn;
        private TextBox searchTxt;
        private DataGridView restorationDataGrid;
        private Button addNewBtn;
        private Button deleteBtn;
        private Button updateBtn;
        private Button resetBtn;
        private OpenFileDialog openBeforePicture;
        private OpenFileDialog openAfterPicture;
        private TableLayoutPanel tableLayoutPanel1;
    }
}