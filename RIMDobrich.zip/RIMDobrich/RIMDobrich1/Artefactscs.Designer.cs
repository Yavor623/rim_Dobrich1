﻿namespace RIMDobrich1
{
    partial class Artefacts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Artefacts));
            bindingSource1 = new BindingSource(components);
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            indexTxt = new TextBox();
            artefactsDataGrid = new DataGridView();
            nameOfMuseumComboBox = new ComboBox();
            techniqueTxt = new TextBox();
            sizeTxt = new TextBox();
            inscriptionOrDateTxt = new TextBox();
            cipherTxt = new TextBox();
            artefactNameTxt = new TextBox();
            oldInventoryIdTxt = new TextBox();
            conditionOfArtefactTxt = new TextBox();
            amountOfArtefactTxt = new TextBox();
            eraTxt = new TextBox();
            madeTheScientificPassportTxt = new TextBox();
            copiesMadeTxt = new TextBox();
            participationInExhibitionsTxt = new TextBox();
            conservationAndRestorationTxt = new TextBox();
            scientificPublicationsTxt = new TextBox();
            bibliographicEnquiryTxt = new TextBox();
            registrationIdOfNMFTxt = new TextBox();
            idOfPhotoNegativeTxt = new TextBox();
            locationOfFindingTxt = new TextBox();
            storageLocationTxt = new TextBox();
            sellerOrDonaterTxt = new TextBox();
            historicalEnquiryTxt = new TextBox();
            idOfActOfAdmissionTxt = new TextBox();
            marriageProtocolAndActOfLiquidationTxt = new TextBox();
            typeComboBox = new ComboBox();
            dateOfRegistrationLabel = new Label();
            dateOfRegistration = new DateTimePicker();
            dateOfCreationOfTheScientificPassportTxt = new DateTimePicker();
            dateOfCreationOfTheScientificPassportLabel = new Label();
            openPictureFileDialog = new OpenFileDialog();
            pictureBtn = new Button();
            dateOfAssesmentProtocol = new DateTimePicker();
            priceOfAssesmentProtocolTxt = new TextBox();
            searchTxt = new TextBox();
            shapeComboBox = new ComboBox();
            materialComboBox = new ComboBox();
            assesmentProtocolIdComboBox = new ComboBox();
            identificationTxt = new TextBox();
            dateOfAssesmentProtocolLabel = new Label();
            collectionscb = new ComboBox();
            resetBtn = new Button();
            weightTxt = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            queriesBtn = new Button();
            sectionNameComboBox = new ComboBox();
            menuBtn = new Button();
            pictureBox = new PictureBox();
            searchBtn = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)artefactsDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(-643, 111);
            label3.Name = "label3";
            label3.Size = new Size(186, 35);
            label3.TabIndex = 38;
            label3.Text = "Име на секция";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(-643, 4);
            label2.Name = "label2";
            label2.Size = new Size(99, 35);
            label2.TabIndex = 37;
            label2.Text = "Индекс";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(-637, 293);
            label1.Name = "label1";
            label1.Size = new Size(110, 35);
            label1.TabIndex = 36;
            label1.Text = "Търсене";
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updateBtn, 3);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(747, 921);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(552, 40);
            updateBtn.TabIndex = 33;
            updateBtn.TabStop = false;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deleteBtn, 3);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(1305, 876);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(553, 39);
            deleteBtn.TabIndex = 32;
            deleteBtn.TabStop = false;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click;
            // 
            // addNewBtn
            // 
            addNewBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewBtn, 3);
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(747, 876);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(552, 39);
            addNewBtn.TabIndex = 31;
            addNewBtn.TabStop = false;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click;
            // 
            // indexTxt
            // 
            indexTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            indexTxt.Location = new Point(3, 66);
            indexTxt.MaxLength = 99;
            indexTxt.Name = "indexTxt";
            indexTxt.PlaceholderText = "Инв. номер";
            indexTxt.Size = new Size(180, 35);
            indexTxt.TabIndex = 29;
            indexTxt.TabStop = false;
            // 
            // artefactsDataGrid
            // 
            artefactsDataGrid.AllowUserToAddRows = false;
            artefactsDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            artefactsDataGrid.BackgroundColor = Color.Tan;
            artefactsDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            artefactsDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(artefactsDataGrid, 6);
            artefactsDataGrid.Cursor = Cursors.PanNW;
            artefactsDataGrid.Location = new Point(747, 66);
            artefactsDataGrid.MultiSelect = false;
            artefactsDataGrid.Name = "artefactsDataGrid";
            artefactsDataGrid.ReadOnly = true;
            artefactsDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(artefactsDataGrid, 18);
            artefactsDataGrid.RowTemplate.Height = 29;
            artefactsDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            artefactsDataGrid.Size = new Size(1111, 804);
            artefactsDataGrid.TabIndex = 28;
            artefactsDataGrid.TabStop = false;
            artefactsDataGrid.CellClick += artefactsDataGrid_CellClick;
            // 
            // nameOfMuseumComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(nameOfMuseumComboBox, 2);
            nameOfMuseumComboBox.DropDownHeight = 250;
            nameOfMuseumComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumComboBox.ForeColor = SystemColors.ControlText;
            nameOfMuseumComboBox.FormattingEnabled = true;
            nameOfMuseumComboBox.IntegralHeight = false;
            nameOfMuseumComboBox.Location = new Point(189, 66);
            nameOfMuseumComboBox.Name = "nameOfMuseumComboBox";
            nameOfMuseumComboBox.RightToLeft = RightToLeft.No;
            nameOfMuseumComboBox.Size = new Size(366, 36);
            nameOfMuseumComboBox.TabIndex = 41;
            nameOfMuseumComboBox.TabStop = false;
            nameOfMuseumComboBox.Text = "Име на музей";
            nameOfMuseumComboBox.KeyPress += sectionNameComboBox_KeyPress;
            // 
            // techniqueTxt
            // 
            tableLayoutPanel1.SetColumnSpan(techniqueTxt, 2);
            techniqueTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            techniqueTxt.Location = new Point(375, 246);
            techniqueTxt.MaxLength = 50;
            techniqueTxt.Name = "techniqueTxt";
            techniqueTxt.PlaceholderText = "Техника";
            techniqueTxt.Size = new Size(353, 35);
            techniqueTxt.TabIndex = 43;
            techniqueTxt.TabStop = false;
            // 
            // sizeTxt
            // 
            sizeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            sizeTxt.Location = new Point(3, 381);
            sizeTxt.MaxLength = 40;
            sizeTxt.Name = "sizeTxt";
            sizeTxt.PlaceholderText = "Размер";
            sizeTxt.Size = new Size(180, 35);
            sizeTxt.TabIndex = 45;
            sizeTxt.TabStop = false;
            // 
            // inscriptionOrDateTxt
            // 
            tableLayoutPanel1.SetColumnSpan(inscriptionOrDateTxt, 4);
            inscriptionOrDateTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            inscriptionOrDateTxt.Location = new Point(3, 291);
            inscriptionOrDateTxt.MaxLength = 400;
            inscriptionOrDateTxt.Multiline = true;
            inscriptionOrDateTxt.Name = "inscriptionOrDateTxt";
            inscriptionOrDateTxt.PlaceholderText = "Надпис или дата";
            tableLayoutPanel1.SetRowSpan(inscriptionOrDateTxt, 2);
            inscriptionOrDateTxt.Size = new Size(725, 70);
            inscriptionOrDateTxt.TabIndex = 46;
            inscriptionOrDateTxt.TabStop = false;
            // 
            // cipherTxt
            // 
            cipherTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            cipherTxt.Location = new Point(561, 111);
            cipherTxt.MaxLength = 10;
            cipherTxt.Name = "cipherTxt";
            cipherTxt.PlaceholderText = "Шифър";
            cipherTxt.Size = new Size(167, 35);
            cipherTxt.TabIndex = 48;
            cipherTxt.TabStop = false;
            // 
            // artefactNameTxt
            // 
            tableLayoutPanel1.SetColumnSpan(artefactNameTxt, 2);
            artefactNameTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            artefactNameTxt.Location = new Point(189, 111);
            artefactNameTxt.MaxLength = 100;
            artefactNameTxt.Name = "artefactNameTxt";
            artefactNameTxt.PlaceholderText = "Име на артефакта";
            artefactNameTxt.Size = new Size(366, 35);
            artefactNameTxt.TabIndex = 49;
            artefactNameTxt.TabStop = false;
            // 
            // oldInventoryIdTxt
            // 
            oldInventoryIdTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            oldInventoryIdTxt.Location = new Point(189, 201);
            oldInventoryIdTxt.MaxLength = 10;
            oldInventoryIdTxt.Name = "oldInventoryIdTxt";
            oldInventoryIdTxt.PlaceholderText = "Стар инвентарен номер";
            oldInventoryIdTxt.Size = new Size(180, 35);
            oldInventoryIdTxt.TabIndex = 50;
            oldInventoryIdTxt.TabStop = false;
            // 
            // conditionOfArtefactTxt
            // 
            conditionOfArtefactTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            conditionOfArtefactTxt.Location = new Point(561, 381);
            conditionOfArtefactTxt.MaxLength = 30;
            conditionOfArtefactTxt.Name = "conditionOfArtefactTxt";
            conditionOfArtefactTxt.PlaceholderText = "Състояние на ДПК";
            conditionOfArtefactTxt.Size = new Size(167, 35);
            conditionOfArtefactTxt.TabIndex = 51;
            conditionOfArtefactTxt.TabStop = false;
            // 
            // amountOfArtefactTxt
            // 
            amountOfArtefactTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            amountOfArtefactTxt.Location = new Point(3, 426);
            amountOfArtefactTxt.MaxLength = 6;
            amountOfArtefactTxt.Name = "amountOfArtefactTxt";
            amountOfArtefactTxt.PlaceholderText = "Брой на ДПК";
            amountOfArtefactTxt.Size = new Size(180, 35);
            amountOfArtefactTxt.TabIndex = 93;
            amountOfArtefactTxt.TabStop = false;
            // 
            // eraTxt
            // 
            eraTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            eraTxt.Location = new Point(375, 381);
            eraTxt.MaxLength = 50;
            eraTxt.Name = "eraTxt";
            eraTxt.PlaceholderText = "Епоха";
            eraTxt.Size = new Size(180, 35);
            eraTxt.TabIndex = 53;
            eraTxt.TabStop = false;
            // 
            // madeTheScientificPassportTxt
            // 
            tableLayoutPanel1.SetColumnSpan(madeTheScientificPassportTxt, 2);
            madeTheScientificPassportTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            madeTheScientificPassportTxt.Location = new Point(375, 606);
            madeTheScientificPassportTxt.MaxLength = 100;
            madeTheScientificPassportTxt.Name = "madeTheScientificPassportTxt";
            madeTheScientificPassportTxt.PlaceholderText = "Изготвил научния паспорт";
            madeTheScientificPassportTxt.Size = new Size(353, 35);
            madeTheScientificPassportTxt.TabIndex = 57;
            madeTheScientificPassportTxt.TabStop = false;
            // 
            // copiesMadeTxt
            // 
            copiesMadeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            copiesMadeTxt.Location = new Point(3, 606);
            copiesMadeTxt.MaxLength = 5;
            copiesMadeTxt.Name = "copiesMadeTxt";
            copiesMadeTxt.PlaceholderText = "Направени копия";
            copiesMadeTxt.Size = new Size(180, 35);
            copiesMadeTxt.TabIndex = 58;
            copiesMadeTxt.TabStop = false;
            // 
            // participationInExhibitionsTxt
            // 
            participationInExhibitionsTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            participationInExhibitionsTxt.Location = new Point(561, 561);
            participationInExhibitionsTxt.MaxLength = 5;
            participationInExhibitionsTxt.Name = "participationInExhibitionsTxt";
            participationInExhibitionsTxt.PlaceholderText = "Участие в изл.";
            participationInExhibitionsTxt.Size = new Size(167, 35);
            participationInExhibitionsTxt.TabIndex = 59;
            participationInExhibitionsTxt.TabStop = false;
            // 
            // conservationAndRestorationTxt
            // 
            conservationAndRestorationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            conservationAndRestorationTxt.Location = new Point(375, 561);
            conservationAndRestorationTxt.MaxLength = 5;
            conservationAndRestorationTxt.Name = "conservationAndRestorationTxt";
            conservationAndRestorationTxt.PlaceholderText = "Консерв. и реставр.";
            conservationAndRestorationTxt.Size = new Size(180, 35);
            conservationAndRestorationTxt.TabIndex = 60;
            conservationAndRestorationTxt.TabStop = false;
            // 
            // scientificPublicationsTxt
            // 
            scientificPublicationsTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            scientificPublicationsTxt.Location = new Point(189, 561);
            scientificPublicationsTxt.MaxLength = 5;
            scientificPublicationsTxt.Name = "scientificPublicationsTxt";
            scientificPublicationsTxt.PlaceholderText = "Научни публик.";
            scientificPublicationsTxt.Size = new Size(180, 35);
            scientificPublicationsTxt.TabIndex = 61;
            scientificPublicationsTxt.TabStop = false;
            // 
            // bibliographicEnquiryTxt
            // 
            bibliographicEnquiryTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            bibliographicEnquiryTxt.Location = new Point(3, 561);
            bibliographicEnquiryTxt.MaxLength = 5;
            bibliographicEnquiryTxt.Name = "bibliographicEnquiryTxt";
            bibliographicEnquiryTxt.PlaceholderText = "Библ. справка за ДПК";
            bibliographicEnquiryTxt.Size = new Size(180, 35);
            bibliographicEnquiryTxt.TabIndex = 62;
            bibliographicEnquiryTxt.TabStop = false;
            // 
            // registrationIdOfNMFTxt
            // 
            registrationIdOfNMFTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            registrationIdOfNMFTxt.Location = new Point(561, 516);
            registrationIdOfNMFTxt.MaxLength = 15;
            registrationIdOfNMFTxt.Name = "registrationIdOfNMFTxt";
            registrationIdOfNMFTxt.PlaceholderText = "Регистрационен номер на НМФ";
            registrationIdOfNMFTxt.Size = new Size(167, 35);
            registrationIdOfNMFTxt.TabIndex = 63;
            registrationIdOfNMFTxt.TabStop = false;
            // 
            // idOfPhotoNegativeTxt
            // 
            idOfPhotoNegativeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            idOfPhotoNegativeTxt.Location = new Point(375, 516);
            idOfPhotoNegativeTxt.MaxLength = 10;
            idOfPhotoNegativeTxt.Name = "idOfPhotoNegativeTxt";
            idOfPhotoNegativeTxt.PlaceholderText = "Номер на фотонегатива";
            idOfPhotoNegativeTxt.Size = new Size(180, 35);
            idOfPhotoNegativeTxt.TabIndex = 64;
            idOfPhotoNegativeTxt.TabStop = false;
            // 
            // locationOfFindingTxt
            // 
            locationOfFindingTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            locationOfFindingTxt.Location = new Point(189, 516);
            locationOfFindingTxt.MaxLength = 125;
            locationOfFindingTxt.Name = "locationOfFindingTxt";
            locationOfFindingTxt.PlaceholderText = "Местонахождение";
            locationOfFindingTxt.Size = new Size(180, 35);
            locationOfFindingTxt.TabIndex = 65;
            locationOfFindingTxt.TabStop = false;
            // 
            // storageLocationTxt
            // 
            storageLocationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            storageLocationTxt.Location = new Point(3, 516);
            storageLocationTxt.Name = "storageLocationTxt";
            storageLocationTxt.PlaceholderText = "Местосъхранение";
            storageLocationTxt.Size = new Size(180, 35);
            storageLocationTxt.TabIndex = 66;
            storageLocationTxt.TabStop = false;
            // 
            // sellerOrDonaterTxt
            // 
            tableLayoutPanel1.SetColumnSpan(sellerOrDonaterTxt, 2);
            sellerOrDonaterTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            sellerOrDonaterTxt.Location = new Point(375, 426);
            sellerOrDonaterTxt.MaxLength = 100;
            sellerOrDonaterTxt.Name = "sellerOrDonaterTxt";
            sellerOrDonaterTxt.PlaceholderText = "От кого е купен или подарен";
            sellerOrDonaterTxt.Size = new Size(353, 35);
            sellerOrDonaterTxt.TabIndex = 68;
            sellerOrDonaterTxt.TabStop = false;
            // 
            // historicalEnquiryTxt
            // 
            historicalEnquiryTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            historicalEnquiryTxt.Location = new Point(189, 426);
            historicalEnquiryTxt.MaxLength = 6;
            historicalEnquiryTxt.Name = "historicalEnquiryTxt";
            historicalEnquiryTxt.PlaceholderText = "Историческа справка";
            historicalEnquiryTxt.Size = new Size(180, 35);
            historicalEnquiryTxt.TabIndex = 69;
            historicalEnquiryTxt.TabStop = false;
            // 
            // idOfActOfAdmissionTxt
            // 
            idOfActOfAdmissionTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            idOfActOfAdmissionTxt.Location = new Point(561, 201);
            idOfActOfAdmissionTxt.MaxLength = 20;
            idOfActOfAdmissionTxt.Multiline = true;
            idOfActOfAdmissionTxt.Name = "idOfActOfAdmissionTxt";
            idOfActOfAdmissionTxt.PlaceholderText = "Номер на акта за приемане и предаване";
            idOfActOfAdmissionTxt.Size = new Size(167, 32);
            idOfActOfAdmissionTxt.TabIndex = 71;
            idOfActOfAdmissionTxt.TabStop = false;
            // 
            // marriageProtocolAndActOfLiquidationTxt
            // 
            marriageProtocolAndActOfLiquidationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            marriageProtocolAndActOfLiquidationTxt.Location = new Point(189, 606);
            marriageProtocolAndActOfLiquidationTxt.MaxLength = 5;
            marriageProtocolAndActOfLiquidationTxt.Name = "marriageProtocolAndActOfLiquidationTxt";
            marriageProtocolAndActOfLiquidationTxt.PlaceholderText = "ПБАЛ";
            marriageProtocolAndActOfLiquidationTxt.Size = new Size(180, 35);
            marriageProtocolAndActOfLiquidationTxt.TabIndex = 72;
            marriageProtocolAndActOfLiquidationTxt.TabStop = false;
            // 
            // typeComboBox
            // 
            typeComboBox.DropDownHeight = 250;
            typeComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            typeComboBox.ForeColor = SystemColors.ControlText;
            typeComboBox.FormattingEnabled = true;
            typeComboBox.IntegralHeight = false;
            typeComboBox.Location = new Point(3, 111);
            typeComboBox.MaxLength = 120;
            typeComboBox.Name = "typeComboBox";
            typeComboBox.Size = new Size(180, 36);
            typeComboBox.TabIndex = 73;
            typeComboBox.TabStop = false;
            typeComboBox.Text = "Видове артефакти";
            typeComboBox.TextUpdate += typeComboBox_TextUpdate;
            typeComboBox.Click += typeComboBox_Click;
            // 
            // dateOfRegistrationLabel
            // 
            dateOfRegistrationLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            dateOfRegistrationLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(dateOfRegistrationLabel, 2);
            dateOfRegistrationLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistrationLabel.Location = new Point(3, 176);
            dateOfRegistrationLabel.Name = "dateOfRegistrationLabel";
            dateOfRegistrationLabel.Size = new Size(173, 22);
            dateOfRegistrationLabel.TabIndex = 74;
            dateOfRegistrationLabel.Text = "Дата на регистрация";
            // 
            // dateOfRegistration
            // 
            dateOfRegistration.CalendarFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistration.Cursor = Cursors.IBeam;
            dateOfRegistration.CustomFormat = "yyyy-MM-dd";
            dateOfRegistration.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistration.Format = DateTimePickerFormat.Custom;
            dateOfRegistration.Location = new Point(3, 201);
            dateOfRegistration.Name = "dateOfRegistration";
            dateOfRegistration.Size = new Size(180, 34);
            dateOfRegistration.TabIndex = 75;
            dateOfRegistration.TabStop = false;
            // 
            // dateOfCreationOfTheScientificPassportTxt
            // 
            tableLayoutPanel1.SetColumnSpan(dateOfCreationOfTheScientificPassportTxt, 2);
            dateOfCreationOfTheScientificPassportTxt.Cursor = Cursors.IBeam;
            dateOfCreationOfTheScientificPassportTxt.CustomFormat = "yyyy-MM-dd";
            dateOfCreationOfTheScientificPassportTxt.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfCreationOfTheScientificPassportTxt.Format = DateTimePickerFormat.Custom;
            dateOfCreationOfTheScientificPassportTxt.Location = new Point(3, 696);
            dateOfCreationOfTheScientificPassportTxt.Name = "dateOfCreationOfTheScientificPassportTxt";
            dateOfCreationOfTheScientificPassportTxt.Size = new Size(366, 32);
            dateOfCreationOfTheScientificPassportTxt.TabIndex = 76;
            dateOfCreationOfTheScientificPassportTxt.TabStop = false;
            // 
            // dateOfCreationOfTheScientificPassportLabel
            // 
            dateOfCreationOfTheScientificPassportLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            dateOfCreationOfTheScientificPassportLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(dateOfCreationOfTheScientificPassportLabel, 2);
            dateOfCreationOfTheScientificPassportLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfCreationOfTheScientificPassportLabel.Location = new Point(3, 671);
            dateOfCreationOfTheScientificPassportLabel.Name = "dateOfCreationOfTheScientificPassportLabel";
            dateOfCreationOfTheScientificPassportLabel.Size = new Size(314, 22);
            dateOfCreationOfTheScientificPassportLabel.TabIndex = 77;
            dateOfCreationOfTheScientificPassportLabel.Text = "Дата на съставяне на научния паспорт";
            // 
            // openPictureFileDialog
            // 
            openPictureFileDialog.Filter = "Image files =(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
            openPictureFileDialog.Title = "Choose a file";
            // 
            // pictureBtn
            // 
            pictureBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(pictureBtn, 2);
            pictureBtn.Cursor = Cursors.Hand;
            pictureBtn.FlatStyle = FlatStyle.Flat;
            pictureBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            pictureBtn.Location = new Point(3, 921);
            pictureBtn.Name = "pictureBtn";
            pictureBtn.Size = new Size(366, 40);
            pictureBtn.TabIndex = 79;
            pictureBtn.TabStop = false;
            pictureBtn.Text = "Добави снимка";
            pictureBtn.UseVisualStyleBackColor = false;
            pictureBtn.Click += picturebtn_Click;
            // 
            // dateOfAssesmentProtocol
            // 
            dateOfAssesmentProtocol.Cursor = Cursors.IBeam;
            dateOfAssesmentProtocol.CustomFormat = "yyyy-MM-dd";
            dateOfAssesmentProtocol.Enabled = false;
            dateOfAssesmentProtocol.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocol.Format = DateTimePickerFormat.Custom;
            dateOfAssesmentProtocol.Location = new Point(375, 471);
            dateOfAssesmentProtocol.Name = "dateOfAssesmentProtocol";
            dateOfAssesmentProtocol.Size = new Size(180, 34);
            dateOfAssesmentProtocol.TabIndex = 81;
            dateOfAssesmentProtocol.TabStop = false;
            // 
            // priceOfAssesmentProtocolTxt
            // 
            priceOfAssesmentProtocolTxt.Enabled = false;
            priceOfAssesmentProtocolTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            priceOfAssesmentProtocolTxt.Location = new Point(561, 471);
            priceOfAssesmentProtocolTxt.Name = "priceOfAssesmentProtocolTxt";
            priceOfAssesmentProtocolTxt.PlaceholderText = "Сума";
            priceOfAssesmentProtocolTxt.Size = new Size(167, 35);
            priceOfAssesmentProtocolTxt.TabIndex = 82;
            priceOfAssesmentProtocolTxt.TabStop = false;
            // 
            // searchTxt
            // 
            tableLayoutPanel1.SetColumnSpan(searchTxt, 2);
            searchTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(3, 831);
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търси по инв. номер";
            searchTxt.Size = new Size(366, 35);
            searchTxt.TabIndex = 83;
            searchTxt.TabStop = false;
            // 
            // shapeComboBox
            // 
            shapeComboBox.DropDownHeight = 250;
            shapeComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            shapeComboBox.ForeColor = SystemColors.ControlText;
            shapeComboBox.FormattingEnabled = true;
            shapeComboBox.IntegralHeight = false;
            shapeComboBox.Location = new Point(375, 201);
            shapeComboBox.Name = "shapeComboBox";
            shapeComboBox.RightToLeft = RightToLeft.No;
            shapeComboBox.Size = new Size(180, 36);
            shapeComboBox.TabIndex = 85;
            shapeComboBox.TabStop = false;
            shapeComboBox.Text = "Форма";
            shapeComboBox.KeyPress += sectionNameComboBox_KeyPress;
            // 
            // materialComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(materialComboBox, 2);
            materialComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            materialComboBox.ForeColor = SystemColors.ControlText;
            materialComboBox.FormattingEnabled = true;
            materialComboBox.Location = new Point(3, 246);
            materialComboBox.Name = "materialComboBox";
            materialComboBox.RightToLeft = RightToLeft.No;
            materialComboBox.Size = new Size(366, 36);
            materialComboBox.TabIndex = 86;
            materialComboBox.TabStop = false;
            materialComboBox.Text = "Материал";
            materialComboBox.KeyPress += sectionNameComboBox_KeyPress;
            // 
            // assesmentProtocolIdComboBox
            // 
            assesmentProtocolIdComboBox.DropDownHeight = 250;
            assesmentProtocolIdComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolIdComboBox.ForeColor = SystemColors.ControlText;
            assesmentProtocolIdComboBox.FormattingEnabled = true;
            assesmentProtocolIdComboBox.IntegralHeight = false;
            assesmentProtocolIdComboBox.Location = new Point(3, 471);
            assesmentProtocolIdComboBox.Name = "assesmentProtocolIdComboBox";
            assesmentProtocolIdComboBox.RightToLeft = RightToLeft.No;
            assesmentProtocolIdComboBox.Size = new Size(180, 36);
            assesmentProtocolIdComboBox.TabIndex = 87;
            assesmentProtocolIdComboBox.TabStop = false;
            assesmentProtocolIdComboBox.Text = "№ ОП";
            assesmentProtocolIdComboBox.SelectedIndexChanged += assesmentpridcb_SelectedIndexChanged;
            assesmentProtocolIdComboBox.KeyPress += sectionNameComboBox_KeyPress;
            // 
            // identificationTxt
            // 
            tableLayoutPanel1.SetColumnSpan(identificationTxt, 2);
            identificationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            identificationTxt.Location = new Point(3, 741);
            identificationTxt.MaxLength = 75;
            identificationTxt.Name = "identificationTxt";
            identificationTxt.PlaceholderText = "Идентификация";
            identificationTxt.Size = new Size(366, 35);
            identificationTxt.TabIndex = 88;
            identificationTxt.TabStop = false;
            // 
            // dateOfAssesmentProtocolLabel
            // 
            dateOfAssesmentProtocolLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dateOfAssesmentProtocolLabel.AutoSize = true;
            dateOfAssesmentProtocolLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocolLabel.Location = new Point(263, 468);
            dateOfAssesmentProtocolLabel.Name = "dateOfAssesmentProtocolLabel";
            dateOfAssesmentProtocolLabel.Size = new Size(106, 22);
            dateOfAssesmentProtocolLabel.TabIndex = 89;
            dateOfAssesmentProtocolLabel.Text = "Дата на ОП:";
            // 
            // collectionscb
            // 
            collectionscb.DropDownHeight = 250;
            collectionscb.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            collectionscb.ForeColor = SystemColors.ControlText;
            collectionscb.FormattingEnabled = true;
            collectionscb.IntegralHeight = false;
            collectionscb.Location = new Point(561, 66);
            collectionscb.Name = "collectionscb";
            collectionscb.RightToLeft = RightToLeft.No;
            collectionscb.Size = new Size(167, 36);
            collectionscb.TabIndex = 90;
            collectionscb.TabStop = false;
            collectionscb.Text = "Сбирки";
            collectionscb.KeyPress += sectionNameComboBox_KeyPress;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(1305, 921);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(553, 40);
            resetBtn.TabIndex = 91;
            resetBtn.TabStop = false;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // weightTxt
            // 
            weightTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            weightTxt.Location = new Point(189, 381);
            weightTxt.MaxLength = 40;
            weightTxt.Name = "weightTxt";
            weightTxt.PlaceholderText = "Тегло";
            weightTxt.Size = new Size(180, 35);
            weightTxt.TabIndex = 92;
            weightTxt.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(queriesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(sectionNameComboBox, 1, 0);
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(indexTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(nameOfMuseumComboBox, 1, 1);
            tableLayoutPanel1.Controls.Add(collectionscb, 3, 1);
            tableLayoutPanel1.Controls.Add(typeComboBox, 0, 2);
            tableLayoutPanel1.Controls.Add(resetBtn, 7, 20);
            tableLayoutPanel1.Controls.Add(artefactNameTxt, 1, 2);
            tableLayoutPanel1.Controls.Add(updateBtn, 4, 20);
            tableLayoutPanel1.Controls.Add(cipherTxt, 3, 2);
            tableLayoutPanel1.Controls.Add(dateOfRegistrationLabel, 0, 3);
            tableLayoutPanel1.Controls.Add(dateOfRegistration, 0, 4);
            tableLayoutPanel1.Controls.Add(oldInventoryIdTxt, 1, 4);
            tableLayoutPanel1.Controls.Add(shapeComboBox, 2, 4);
            tableLayoutPanel1.Controls.Add(idOfActOfAdmissionTxt, 3, 4);
            tableLayoutPanel1.Controls.Add(materialComboBox, 0, 5);
            tableLayoutPanel1.Controls.Add(inscriptionOrDateTxt, 0, 6);
            tableLayoutPanel1.Controls.Add(sizeTxt, 0, 8);
            tableLayoutPanel1.Controls.Add(weightTxt, 1, 8);
            tableLayoutPanel1.Controls.Add(conditionOfArtefactTxt, 3, 8);
            tableLayoutPanel1.Controls.Add(amountOfArtefactTxt, 0, 9);
            tableLayoutPanel1.Controls.Add(historicalEnquiryTxt, 1, 9);
            tableLayoutPanel1.Controls.Add(sellerOrDonaterTxt, 2, 9);
            tableLayoutPanel1.Controls.Add(assesmentProtocolIdComboBox, 0, 10);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocol, 2, 10);
            tableLayoutPanel1.Controls.Add(priceOfAssesmentProtocolTxt, 3, 10);
            tableLayoutPanel1.Controls.Add(storageLocationTxt, 0, 11);
            tableLayoutPanel1.Controls.Add(locationOfFindingTxt, 1, 11);
            tableLayoutPanel1.Controls.Add(idOfPhotoNegativeTxt, 2, 11);
            tableLayoutPanel1.Controls.Add(registrationIdOfNMFTxt, 3, 11);
            tableLayoutPanel1.Controls.Add(bibliographicEnquiryTxt, 0, 12);
            tableLayoutPanel1.Controls.Add(scientificPublicationsTxt, 1, 12);
            tableLayoutPanel1.Controls.Add(conservationAndRestorationTxt, 2, 12);
            tableLayoutPanel1.Controls.Add(participationInExhibitionsTxt, 3, 12);
            tableLayoutPanel1.Controls.Add(copiesMadeTxt, 0, 13);
            tableLayoutPanel1.Controls.Add(marriageProtocolAndActOfLiquidationTxt, 1, 13);
            tableLayoutPanel1.Controls.Add(madeTheScientificPassportTxt, 2, 13);
            tableLayoutPanel1.Controls.Add(techniqueTxt, 2, 5);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocolLabel, 1, 10);
            tableLayoutPanel1.Controls.Add(eraTxt, 2, 8);
            tableLayoutPanel1.Controls.Add(deleteBtn, 7, 19);
            tableLayoutPanel1.Controls.Add(searchTxt, 0, 18);
            tableLayoutPanel1.Controls.Add(identificationTxt, 0, 16);
            tableLayoutPanel1.Controls.Add(dateOfCreationOfTheScientificPassportTxt, 0, 15);
            tableLayoutPanel1.Controls.Add(dateOfCreationOfTheScientificPassportLabel, 0, 14);
            tableLayoutPanel1.Controls.Add(pictureBox, 2, 15);
            tableLayoutPanel1.Controls.Add(artefactsDataGrid, 4, 1);
            tableLayoutPanel1.Controls.Add(addNewBtn, 4, 19);
            tableLayoutPanel1.Controls.Add(searchBtn, 0, 19);
            tableLayoutPanel1.Controls.Add(pictureBtn, 0, 20);
            tableLayoutPanel1.Location = new Point(12, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 21;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 6.62932F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.668535F));
            tableLayoutPanel1.Size = new Size(1861, 964);
            tableLayoutPanel1.TabIndex = 93;
            // 
            // queriesBtn
            // 
            queriesBtn.BackColor = Color.NavajoWhite;
            queriesBtn.Cursor = Cursors.Hand;
            queriesBtn.FlatStyle = FlatStyle.Flat;
            queriesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            queriesBtn.Location = new Point(747, 3);
            queriesBtn.Name = "queriesBtn";
            queriesBtn.Size = new Size(180, 43);
            queriesBtn.TabIndex = 95;
            queriesBtn.TabStop = false;
            queriesBtn.Text = "Заявки";
            queriesBtn.UseVisualStyleBackColor = false;
            queriesBtn.Click += queriesBtn_Click_1;
            // 
            // sectionNameComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(sectionNameComboBox, 3);
            sectionNameComboBox.DropDownHeight = 250;
            sectionNameComboBox.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            sectionNameComboBox.ForeColor = SystemColors.ControlText;
            sectionNameComboBox.FormattingEnabled = true;
            sectionNameComboBox.IntegralHeight = false;
            sectionNameComboBox.Location = new Point(189, 3);
            sectionNameComboBox.Name = "sectionNameComboBox";
            sectionNameComboBox.RightToLeft = RightToLeft.No;
            sectionNameComboBox.Size = new Size(552, 45);
            sectionNameComboBox.TabIndex = 94;
            sectionNameComboBox.TabStop = false;
            sectionNameComboBox.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(180, 43);
            menuBtn.TabIndex = 94;
            menuBtn.TabStop = false;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // pictureBox
            // 
            pictureBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            tableLayoutPanel1.SetColumnSpan(pictureBox, 2);
            pictureBox.Location = new Point(375, 696);
            pictureBox.Name = "pictureBox";
            tableLayoutPanel1.SetRowSpan(pictureBox, 6);
            pictureBox.Size = new Size(366, 265);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.TabIndex = 78;
            pictureBox.TabStop = false;
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(searchBtn, 2);
            searchBtn.Cursor = Cursors.Hand;
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            searchBtn.Location = new Point(3, 876);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(366, 39);
            searchBtn.TabIndex = 100;
            searchBtn.TabStop = false;
            searchBtn.Text = "Търси";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchBtn_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.NavajoWhite;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(3, 951);
            button1.Name = "button1";
            button1.Size = new Size(366, 24);
            button1.TabIndex = 103;
            button1.TabStop = false;
            button1.Text = "Търси";
            button1.UseVisualStyleBackColor = false;
            // 
            // Artefacts
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1500, 724);
            Name = "Artefacts";
            Text = "Артефакти";
            Load += Artefactscs_Load;
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)artefactsDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private BindingSource bindingSource1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private TextBox indexTxt;
        private DataGridView artefactsDataGrid;
        private ComboBox nameOfMuseumComboBox;
        private TextBox techniqueTxt;
        private TextBox sizeTxt;
        private TextBox inscriptionOrDateTxt;
        private TextBox cipherTxt;
        private TextBox artefactNameTxt;
        private TextBox oldInventoryIdTxt;
        private TextBox conditionOfArtefactTxt;
        private TextBox amountOfArtefactTxt;
        private TextBox eraTxt;
        private TextBox madeTheScientificPassportTxt;
        private TextBox copiesMadeTxt;
        private TextBox participationInExhibitionsTxt;
        private TextBox conservationAndRestorationTxt;
        private TextBox scientificPublicationsTxt;
        private TextBox bibliographicEnquiryTxt;
        private TextBox registrationIdOfNMFTxt;
        private TextBox idOfPhotoNegativeTxt;
        private TextBox locationOfFindingTxt;
        private TextBox storageLocationTxt;
        private TextBox sellerOrDonaterTxt;
        private TextBox historicalEnquiryTxt;
        private TextBox idOfActOfAdmissionTxt;
        private TextBox marriageProtocolAndActOfLiquidationTxt;
        private ComboBox typeComboBox;
        private Label dateOfRegistrationLabel;
        private DateTimePicker dateOfRegistration;
        private Label dateOfCreationOfTheScientificPassportLabel;
        private OpenFileDialog openPictureFileDialog;
        private Button pictureBtn;
        private DateTimePicker dateOfAssesmentProtocol;
        private TextBox priceOfAssesmentProtocolTxt;
        private TextBox searchTxt;
        private ComboBox shapeComboBox;
        private ComboBox materialComboBox;
        private ComboBox assesmentProtocolIdComboBox;
        private TextBox identificationTxt;
        private Label dateOfAssesmentProtocolLabel;
        private ComboBox collectionscb;
        private Button resetBtn;
        private TextBox weightTxt;
        private DateTimePicker dateOfCreationOfTheScientificPassportTxt;
        private TableLayoutPanel tableLayoutPanel1;
        private Button searchBtn;
        private PictureBox pictureBox;
        private ImageList imageListArtefacts;
        private Button button1;
        private Button menuBtn;
        private ComboBox sectionNameComboBox;
        private Button queriesBtn;
        private Button backPicBtn;
        private Button nextPicBtn;
    }
}