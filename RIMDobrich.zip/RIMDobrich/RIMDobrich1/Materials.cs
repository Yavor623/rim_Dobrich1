﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class Materials : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataReader sqlRd;

        public Materials()
        {
            InitializeComponent();
        }

        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.materialDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.materialDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.materialDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.materialDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.materialDataGrid.GridColor = Color.BlueViolet;
        }

        //Избира данните от таблицата materials и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT material_id AS 'Индекс', material_name AS 'Материал' FROM rim_dobrich.materials";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            materialDataGrid.DataSource = sqlDT;
        }

        private void addNewbtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            try
            {
                sqlConn.Open();

                //Вмъква в таблицата materials съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.materials(material_id,material_name) VALUES('{materialIdTxt.Text}','{materialTxt.Text}')";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

                MessageBox.Show($"Успешно добавяне на {materialTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                materialIdTxt.Text = string.Empty;
                materialTxt.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {materialTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void Materials_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                //Премахва от таблицата materials реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;
                sqlCmd.CommandText = $"DELETE FROM rim_dobrich.materials WHERE material_id={materialIdTxt.Text};";
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                foreach (DataGridViewRow item in this.materialDataGrid.SelectedRows)
                {
                    materialDataGrid.Rows.RemoveAt(item.Index);

                }
                MessageBox.Show($"Успешно изтриване на {materialTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                materialIdTxt.Text = string.Empty;
                materialTxt.Text = string.Empty;
                UploadData();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изтриване на {materialTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {
                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата materials 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.materials SET material_id=@material_id, material_name=@material_name  WHERE material_id=@material_id";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@material_id", materialIdTxt.Text);
                sqlCmd.Parameters.AddWithValue("@material_name", materialTxt.Text);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяване на {materialTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                materialIdTxt.Text = string.Empty;
                materialTxt.Text = string.Empty;

                UploadData();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {materialTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void descriprionDataGrid_CellClick(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                materialIdTxt.Text = materialDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                materialTxt.Text = materialDataGrid.SelectedRows[0].Cells[1].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Shapes description = new Shapes();
            Menu menu = new Menu();
            menu.Show();

            description.Close();
            this.Hide();
        }

        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Shapes description = new Shapes();
            Sections sections = new Sections();
            sections.Show();

            description.Close();
            this.Hide();
        }
        private void nameOfMuseumbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            Materials materials = new Materials();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();
            materials.Close();
            this.Hide();
        }

        private void typesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Materials materials = new Materials();
            Types types = new Types();
            types.Show();
            materials.Close();
            this.Hide();
        }

        private void collectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Materials materials = new Materials();
            CollectionsMuseum collections = new CollectionsMuseum();
            collections.Show();
            materials.Close();
            this.Hide();
        }

        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Materials materials = new Materials();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            materials.Close();
            this.Hide();
        }

        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Materials materials = new Materials();
            Shapes description = new Shapes();
            description.Show();
            materials.Close();
            this.Hide();
        }

        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {

            Materials materials = new Materials();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            materials.Close();
            this.Hide();
        }
        private void queriesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Materials materials = new Materials();
            Queries queries = new Queries();
            queries.Show();
            materials.Close();
            this.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Връща началните стойности, занулира
            materialIdTxt.Text = string.Empty;
            materialTxt.Text = string.Empty;
        }

        private void materialIdTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }
    }
}
