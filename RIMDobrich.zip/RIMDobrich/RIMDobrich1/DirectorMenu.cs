﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class DirectorMenu : Form
    {
        public string DirectorPassword { get; set; }
        public DirectorMenu(string directorPassword)
        {
            this.DirectorPassword = directorPassword;
            InitializeComponent();
        }
        public DirectorMenu()
        {
            InitializeComponent();
        }

        private void deleteAccountButton_Click(object sender, EventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            DeletingAccount deletingAccount = new DeletingAccount(DirectorPassword);
            deletingAccount.Show();
            this.Hide();
            directorMenu.Close();
        }

        private void createAccountButton_Click(object sender, EventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            CreateAccount createAccount = new CreateAccount(DirectorPassword);
            createAccount.Show();
            this.Hide();
            directorMenu.Close();
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            Menu menu = new Menu();
            menu.Show();
            this.Hide();
            directorMenu.Close();
        }
    }
}
