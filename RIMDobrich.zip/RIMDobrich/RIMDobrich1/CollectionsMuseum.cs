﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class CollectionsMuseum : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataReader sqlRd;
        public CollectionsMuseum()
        {
            InitializeComponent();
        }
        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.materialDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.materialDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.materialDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.materialDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.materialDataGrid.GridColor = Color.BlueViolet;
        }
        //Избира данните от таблицата collections и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT collection_id AS 'Индекс', collection_name AS 'Сбирка' FROM rim_dobrich.collections";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            materialDataGrid.DataSource = sqlDT;
        }
        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата collections реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.collections WHERE collection_id={collectionIdTxt.Text};";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                MessageBox.Show($"Успешно премахване на {collectionNameTxt.Text}", "", MessageBoxButtons.OK);
                foreach (DataGridViewRow item in this.materialDataGrid.SelectedRows)
                {
                    materialDataGrid.Rows.RemoveAt(item.Index);

                }
                //Връща началните стойности, занулира
                collectionIdTxt.Text = string.Empty;
                collectionNameTxt.Text = string.Empty;
                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно премахване на {collectionNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void addNewbtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            try
            {
                sqlConn.Open();
                //Вмъква в таблицата collections съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.collections(collection_id,collection_name) VALUES('{collectionIdTxt.Text}','{collectionNameTxt.Text}')";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

                MessageBox.Show($"Успешно добавяне на {collectionNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                collectionIdTxt.Text = string.Empty;
                collectionNameTxt.Text = string.Empty;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {collectionNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {
                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата collections 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.collections SET collection_id=@collection_id, collection_name=@collection_name  WHERE collection_id=@collection_id";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@collection_id", collectionIdTxt.Text);
                sqlCmd.Parameters.AddWithValue("@collection_name", collectionNameTxt.Text);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяване на {collectionNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                collectionIdTxt.Text = string.Empty;
                collectionNameTxt.Text = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {collectionNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Collections_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }

        private void materialDataGrid_CellClick(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                collectionIdTxt.Text = materialDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                collectionNameTxt.Text = materialDataGrid.SelectedRows[0].Cells[1].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Menu menu = new Menu();
            CollectionsMuseum collections = new CollectionsMuseum();
            menu.Show();
            collections.Close();
            this.Hide();

        }

        private void artefactsbtn_Click(object sender, EventArgs e)  //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Artefacts artefactscs = new Artefacts();
            CollectionsMuseum collections = new CollectionsMuseum();
            artefactscs.Show();
            collections.Close();
            this.Hide();
        }

        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Sections sections = new Sections();
            CollectionsMuseum collections = new CollectionsMuseum();
            sections.Show();
            collections.Close();
            this.Hide();
        }

        private void typesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Types types = new Types();
            CollectionsMuseum collections = new CollectionsMuseum();
            types.Show();
            collections.Close();
            this.Hide();
        }

        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Shapes shapes = new Shapes();
            CollectionsMuseum collections = new CollectionsMuseum();
            shapes.Show();
            collections.Close();
            this.Hide();
        }

        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {
            Materials materials = new Materials();
            CollectionsMuseum collections = new CollectionsMuseum();
            materials.Show();
            collections.Close();
            this.Hide();
        }
        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            AssesmentProtocol assesment = new AssesmentProtocol();
            CollectionsMuseum collections = new CollectionsMuseum();
            assesment.Show();
            collections.Close();
            this.Hide();
        }

        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            NameOfMuseum nameOfMuseum = new NameOfMuseum();
            CollectionsMuseum collections = new CollectionsMuseum();
            nameOfMuseum.Show();
            collections.Close();
            this.Hide();
        }

        private void queriesbtn_Click(object sender, EventArgs e)  //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Queries queries = new Queries();
            CollectionsMuseum collections = new CollectionsMuseum();
            queries.Show();
            collections.Close();
            this.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Връща началните стойности, занулира
            collectionIdTxt.Text = string.Empty;
            collectionNameTxt.Text = string.Empty;
        }

        private void collectionIdTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void collectionNameTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }
    }
}
