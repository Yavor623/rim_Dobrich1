﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Pqc.Crypto.Lms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RIMDobrich1
{
    public partial class Artefacts : Form
    {
        public int SectionId { get; set; }
        public int Privilege { get; set; }
        /*public string PictureName0 { get; set; }
        public string PictureName1 { get; set; }
        public string PictureName2 { get; set; }
        public string PictureName3 { get; set; }
        public string PictureName4 { get; set; }
        public string PictureName5 { get; set; }*/

        bool IsItAPicture = false;
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataReader sqlRd;

        String pictureName = "";
        String chosenPictureAddress = Directory.GetCurrentDirectory();
        String fullDirection = "";
        string[] pictures;


        public Artefacts()
        {
            InitializeComponent();
        }
        /*public Artefacts(string pictureName, string picture1Name, string picture2Name, string picture3Name, string picture4Name, string picture5Name)
        {
            pictures = new string[] { pictureName, picture1Name, picture2Name, picture3Name, picture4Name, picture5Name };
            IsItAPicture = true;
            this.PictureName0 = pictureName;
            this.PictureName1 = picture1Name;
            this.PictureName2 = picture2Name;
            this.PictureName3 = picture3Name;
            this.PictureName4 = picture4Name;
            this.PictureName5 = picture5Name;
            InitializeComponent();
        }*/
        public Artefacts(int sectionId, int privilege)
        {
            InitializeComponent();
            this.SectionId = sectionId;
            this.Privilege = privilege;
        }
        private void SetFontAndColors() //Задава фонта и цвета на dataGridView
        {
            this.artefactsDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.artefactsDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.artefactsDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.artefactsDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.artefactsDataGrid.GridColor = Color.BlueViolet;
        }
        public void UploadData() //Избира данните от таблицата artefacts плюс данни от другите таблици и ги изкарва в dataGridView
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            if (Privilege == 4)
            {
                sqlCmd.CommandText = "SELECT id AS 'Инв. номер',rim_dobrich.nameofmuseum.museum_name AS 'Музей',rim_dobrich.collections.collection_name AS 'Сбирка' ,rim_dobrich.types.type_name AS 'Вид',artefact_name AS 'Име',rim_dobrich.description.shape_name AS 'Форма',rim_dobrich.materials.material_name AS 'Материал',technology AS 'Техника',inscriptionordate AS 'Надписи или дати', size AS 'Размер',weight AS 'Тегло',era AS 'Епоха',pictureaddress AS 'Адрес на снимка'" +
                    " FROM rim_dobrich.artefacts  " +
           "LEFT JOIN rim_dobrich.sections ON rim_dobrich.sections.section_id =rim_dobrich.artefacts.section_id " +
           "LEFT JOIN rim_dobrich.types ON rim_dobrich.types.type_id = rim_dobrich.artefacts.type_id " +
           "LEFT JOIN rim_dobrich.nameofmuseum ON rim_dobrich.nameofmuseum.museum_id = rim_dobrich.artefacts.museum_id " +
           "LEFT JOIN rim_dobrich.description ON rim_dobrich.description.shape_id=rim_dobrich.artefacts.shape_id " +
           "LEFT JOIN rim_dobrich.collections ON rim_dobrich.collections.collection_id = rim_dobrich.artefacts.collection_id " +
           "LEFT JOIN rim_dobrich.assesmentprotocol ON rim_dobrich.assesmentprotocol.assesmentpr_id=rim_dobrich.artefacts.assesmentprotocol_id " +
           "LEFT JOIN rim_dobrich.materials ON rim_dobrich.materials.material_id=rim_dobrich.artefacts.material_id " +
           $"WHERE rim_dobrich.artefacts.section_id='{sectionNameComboBox.SelectedIndex + 1}'";
            }
            else
            {
                sqlCmd.CommandText = "SELECT id AS 'Инв. номер',rim_dobrich.nameofmuseum.museum_name AS 'Музей',rim_dobrich.collections.collection_name AS 'Сбирка' ,rim_dobrich.types.type_name AS 'Вид',artefact_name AS 'Име',cipher AS 'Шифър',dateofregistration AS 'Дата на регистрация',oldinventoryid AS 'Стар инв. номер',rim_dobrich.description.shape_name AS 'Форма',idofactofadmission AS 'Номер на акта за приемане и предаване',rim_dobrich.materials.material_name AS 'Материал',technology AS 'Техника',inscriptionordate AS 'Надписи или дати', size AS 'Размер',weight AS 'Тегло',era AS 'Епоха',conditionofartefact AS 'Състояние на ДПК'," +
                        "amountoftheartefact AS 'Брой на ДПК',historicalenquiryid AS 'Историческа справка',sellerordonater AS 'От кого е купен или подарен',assesmentprotocol_id AS '№ ОП',rim_dobrich.assesmentprotocol.assesmentpr_date AS 'Дата на ОП',rim_dobrich.assesmentprotocol.assesmentpr_price AS 'Цена на ОП',storagelocation_id AS 'Местосъхранение',locationoffinding AS 'Местонахождение',idofphotonegative AS 'Номер на фотонегатива',registrationidofNMF AS 'Регистрационен номер на НМФ',bibliographicenquiry AS 'Библ. справка за ДПК',scientificpublications AS 'Научни публик.',conservationandrestorationid AS 'Консерв. и реставр.',participationinexhibitions AS 'Участие в изл.',copiesmade AS 'Направени копия',marriageprotocolandactofliquidation AS 'ПБАЛ',madethescientificpassport AS 'Изготвил научния паспорт',dateofcreationofthescientificpassport AS 'Дата на съставяне на научния паспорт',identification AS 'Идентификация',pictureaddress AS 'Адрес на снимка' FROM rim_dobrich.artefacts " +
               "LEFT JOIN rim_dobrich.sections ON rim_dobrich.sections.section_id =rim_dobrich.artefacts.section_id " +
               "LEFT JOIN rim_dobrich.types ON rim_dobrich.types.type_id = rim_dobrich.artefacts.type_id " +
               "LEFT JOIN rim_dobrich.nameofmuseum ON rim_dobrich.nameofmuseum.museum_id = rim_dobrich.artefacts.museum_id " +
               "LEFT JOIN rim_dobrich.description ON rim_dobrich.description.shape_id=rim_dobrich.artefacts.shape_id " +
               "LEFT JOIN rim_dobrich.collections ON rim_dobrich.collections.collection_id = rim_dobrich.artefacts.collection_id " +
               "LEFT JOIN rim_dobrich.assesmentprotocol ON rim_dobrich.assesmentprotocol.assesmentpr_id=rim_dobrich.artefacts.assesmentprotocol_id " +
               "LEFT JOIN rim_dobrich.materials ON rim_dobrich.materials.material_id=rim_dobrich.artefacts.material_id " +
               $"WHERE rim_dobrich.artefacts.section_id='{sectionNameComboBox.SelectedIndex + 1}'";
            }

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);
            sqlRd.Close();
            sqlConn.Close();

            artefactsDataGrid.DataSource = sqlDT;

        }
        public void UploadComboBoxDataAssesmentProtocol()  //Добавя елементите на комбобокса от таблицата assesmentprotocol
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.assesmentprotocol"; //Избира всичко от таблицата assesmentprotocol
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                assesmentProtocolIdComboBox.Items.Add(reader.GetInt16("assesmentpr_id")); //Добавя елементите от колоната assesmentpr_id в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataCollections() //Добавя елементите на комбобокса от таблицата description
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.collections"; //Избира всичко от таблицата collections
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                collectionscb.Items.Add(reader.GetString("collection_name")); //Добавя елементите от колоната collection_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataShapes() //Добавя елементите на комбобокса от таблицата description
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.description"; //Избира всичко от таблицата description
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                shapeComboBox.Items.Add(reader.GetString("shape_name")); //Добавя елементите от колоната shape_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataMaterials() //Добавя елементите на комбобокса от таблицата materials
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.materials"; //Избира всичко от таблицата materials
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                materialComboBox.Items.Add(reader.GetString("material_name")); //Добавя елементите от колоната material_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataNameOfMuseum() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.nameofmuseum"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                nameOfMuseumComboBox.Items.Add(reader.GetString("museum_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }

        public void UploadComboBoxDataSections()  //Добавя елементите на комбобокса от таблицата sections
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.sections"; //Избира всичко от таблицата sections
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                sectionNameComboBox.Items.Add(reader.GetString("section_name")); //Добавя елементите от колоната section_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxTypes() //Добавя елементите на комбобокса от таблицата types
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.types"; //Избира всичко от таблицата types
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                typeComboBox.Items.Add(reader.GetString("type_name")); //Добавя елементите от колоната type_name в комбобокса
            }
            sqlConn.Close();
        }

        private void addNewbtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {
                //Превръща индекса на избрания елемент в индекса на съответната таблица
                int nameOfMuseumId = nameOfMuseumComboBox.SelectedIndex + 1;
                //int sectionsId = sectionsComboBox.SelectedIndex + 1;
                int typesId = typeComboBox.SelectedIndex + 1;
                int shapesId = shapeComboBox.SelectedIndex + 1;
                int materialsId = materialComboBox.SelectedIndex + 1;
                int collectionsId = collectionscb.SelectedIndex + 1;
                string idAssesmentProtocol = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToInt16(idAssesmentProtocol);

                //Вмъква в таблицата artefacts съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.artefacts(id,museum_id,section_id,collection_id,type_id ,artefact_name,cipher,dateofregistration,oldinventoryid,idofactofadmission,shape_id,material_id,technology,inscriptionordate,size,weight,era,conditionofartefact,amountoftheartefact,historicalenquiryid,sellerordonater,assesmentprotocol_id," +
                    $"storagelocation_id,locationoffinding,idofphotonegative" +
                    $",registrationidofNMF,bibliographicenquiry,scientificpublications,conservationandrestorationid,participationinexhibitions,copiesmade,marriageprotocolandactofliquidation,madethescientificpassport,dateofcreationofthescientificpassport" +
                    $",identification,pictureaddress)" +
                    $"VALUES('{indexTxt.Text}','{nameOfMuseumId}','{sectionNameComboBox.SelectedIndex + 1}','{collectionsId}','{typesId}','{artefactNameTxt.Text}','{cipherTxt.Text}','{dateOfRegistration.Text}','{oldInventoryIdTxt.Text}'," +
                    $"'{idOfActOfAdmissionTxt.Text}','{shapesId}','{materialsId}','{techniqueTxt.Text}','{inscriptionOrDateTxt.Text}','{sizeTxt.Text}','{weightTxt.Text}','{eraTxt.Text}','{conditionOfArtefactTxt.Text}','{amountOfArtefactTxt.Text}','{historicalEnquiryTxt.Text}'," +
                    $"'{sellerOrDonaterTxt.Text}','{idAssesmentProtocol}','{storageLocationTxt.Text}','{locationOfFindingTxt.Text}','{idOfPhotoNegativeTxt.Text}','{registrationIdOfNMFTxt.Text}','{bibliographicEnquiryTxt.Text}','{scientificPublicationsTxt.Text}','{conservationAndRestorationTxt.Text}','{participationInExhibitionsTxt.Text}'," +
                    $"'{copiesMadeTxt.Text}','{marriageProtocolAndActOfLiquidationTxt.Text}','{madeTheScientificPassportTxt.Text}','{dateOfCreationOfTheScientificPassportTxt.Text}','{identificationTxt.Text}','{pictureName}')";
                ;

                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();


                MessageBox.Show($"Успешно добавяне на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                //sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();
            try
            {
                //Превръща индекса на избрания елемент в индекса на съответната таблица
                int nameOfMuseumId = nameOfMuseumComboBox.SelectedIndex + 1;
                //int sectionsId = sectionsComboBox.SelectedIndex + 1;
                int typesId = typeComboBox.SelectedIndex + 1;
                int shapesId = shapeComboBox.SelectedIndex + 1;
                int materialsId = materialComboBox.SelectedIndex + 1;
                int collectionsId = collectionscb.SelectedIndex + 1;
                string idAssesmentProtocol = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToInt16(idAssesmentProtocol);

                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата artefacts 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.artefacts SET id=@id,museum_id=@museum_id,collection_id=@collection_id,type_id=@type_id ,artefact_name=@artefact_name,cipher=@cipher,dateofregistration=@dateofregistration," +
                    $"oldinventoryid=@oldinventoryid,idofactofadmission=@idofactofadmission,shape_id=@shape_id,material_id=@material_id,technology=@technology,inscriptionordate=@inscriptionordate,size=@size,weight=@weight,era=@era,conditionofartefact=@conditionofartefact_id,amountoftheartefact=@amountoftheartefact,historicalenquiryid=@historicalenquiry_id" +
                    $",sellerordonater=@sellerordonater,assesmentprotocol_id=@assesmentprotocol_id,storagelocation_id=@storagelocation_id,locationoffinding=@locationoffinding,idofphotonegative=@idofphotonegative,registrationidofNMF=@registrationidofNMF," +
                    $"bibliographicenquiry=@bibliographicenquiry,scientificpublications=@scientificpublications,conservationandrestorationid=@conservationandrestoration_id,participationinexhibitions=@participationinexhibitions" +
                    $",copiesmade=@copiesmade,marriageprotocolandactofliquidation=@marriageprotocolandactofliquidation,madethescientificpassport=@madethescientificpassport,dateofcreationofthescientificpassport=@dateofcreationofthescientificpassport ,identification=@identification,pictureaddress=@pictureaddress  WHERE id=@id";

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@id", indexTxt.Text);
                sqlCmd.Parameters.AddWithValue("@museum_id", nameOfMuseumId);
                //sqlCmd.Parameters.AddWithValue("@section_id", sectionsId);
                sqlCmd.Parameters.AddWithValue("@collection_id", collectionsId);
                sqlCmd.Parameters.AddWithValue("@type_id", typesId);
                sqlCmd.Parameters.AddWithValue("@artefact_name", artefactNameTxt.Text);
                sqlCmd.Parameters.AddWithValue("@cipher", cipherTxt.Text);
                sqlCmd.Parameters.AddWithValue("@dateofregistration", dateOfRegistration.Text);
                sqlCmd.Parameters.AddWithValue("@oldinventoryid", oldInventoryIdTxt.Text);
                sqlCmd.Parameters.AddWithValue("@idofactofadmission", idOfActOfAdmissionTxt.Text);
                sqlCmd.Parameters.AddWithValue("@shape_id", shapesId);
                sqlCmd.Parameters.AddWithValue("@material_id", materialsId);
                sqlCmd.Parameters.AddWithValue("@technology", techniqueTxt.Text);
                sqlCmd.Parameters.AddWithValue("@inscriptionordate", inscriptionOrDateTxt.Text);
                sqlCmd.Parameters.AddWithValue("@size", sizeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@weight", weightTxt.Text);
                sqlCmd.Parameters.AddWithValue("@era", eraTxt.Text);
                sqlCmd.Parameters.AddWithValue("@conditionofartefact_id", conditionOfArtefactTxt.Text);
                sqlCmd.Parameters.AddWithValue("@amountoftheartefact", amountOfArtefactTxt.Text);
                sqlCmd.Parameters.AddWithValue("@historicalenquiry_id", historicalEnquiryTxt.Text);
                sqlCmd.Parameters.AddWithValue("@sellerordonater", sellerOrDonaterTxt.Text);
                sqlCmd.Parameters.AddWithValue("@assesmentprotocol_id", idAssesmentProtocol);
                sqlCmd.Parameters.AddWithValue("@storagelocation_id", storageLocationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@locationoffinding", locationOfFindingTxt.Text);
                sqlCmd.Parameters.AddWithValue("@idofphotonegative", idOfPhotoNegativeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@registrationidofNMF", registrationIdOfNMFTxt.Text);
                sqlCmd.Parameters.AddWithValue("@bibliographicenquiry", bibliographicEnquiryTxt.Text);
                sqlCmd.Parameters.AddWithValue("@scientificpublications", scientificPublicationsTxt.Text);
                sqlCmd.Parameters.AddWithValue("@conservationandrestoration_id", conservationAndRestorationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@participationinexhibitions", participationInExhibitionsTxt.Text);
                sqlCmd.Parameters.AddWithValue("@copiesmade", copiesMadeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@marriageprotocolandactofliquidation", marriageProtocolAndActOfLiquidationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@madethescientificpassport", madeTheScientificPassportTxt.Text);
                sqlCmd.Parameters.AddWithValue("@dateofcreationofthescientificpassport", dateOfCreationOfTheScientificPassportTxt.Text);
                sqlCmd.Parameters.AddWithValue("@identification", identificationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@pictureaddress", pictureName);

                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяне на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                //sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата artefacts реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.artefacts WHERE id={indexTxt.Text};";

                MessageBox.Show($"Успешно изтриване на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                //sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изтриване на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //Премахва от artefactsDataGrid реда, който отговаря на индекса на селектирания ред в него
            foreach (DataGridViewRow item in this.artefactsDataGrid.SelectedRows)
            {
                artefactsDataGrid.Rows.RemoveAt(item.Index);

            }

        }
        private void Artefactscs_Load(object sender, EventArgs e)
        {
            if (IsItAPicture)
            {
                PictureAdding();
            }
            SetFontAndColors();
            UploadData();
            UploadComboBoxDataNameOfMuseum();
            UploadComboBoxDataSections();
            UploadComboBoxTypes();
            UploadComboBoxDataShapes();
            UploadComboBoxDataMaterials();
            UploadComboBoxDataCollections();
            UploadComboBoxDataAssesmentProtocol();
            PrivilegeManagement();
        }

        private void artefactsDataGrid_CellClick(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                if (Privilege == 4 || Privilege == 5)
                {
                    indexTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                    nameOfMuseumComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[1].Value.ToString();
                    collectionscb.Text = artefactsDataGrid.SelectedRows[0].Cells[2].Value.ToString();
                    typeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[3].Value.ToString();
                    artefactNameTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[4].Value.ToString();
                    shapeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[5].Value.ToString();
                    materialComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[6].Value.ToString();
                    techniqueTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[7].Value.ToString();
                    inscriptionOrDateTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[8].Value.ToString();
                    sizeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[9].Value.ToString();
                    weightTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[10].Value.ToString();
                    eraTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[11].Value.ToString();
                    pictureName = artefactsDataGrid.SelectedRows[0].Cells[12].Value.ToString();
                    fullDirection = chosenPictureAddress + "\\MuseumPictures\\" + pictureName;
                    pictureBox.ImageLocation = fullDirection;
                }
                else if (Privilege == 1 || Privilege == 2 || Privilege == 3)
                {
                    indexTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                    nameOfMuseumComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[1].Value.ToString();
                    collectionscb.Text = artefactsDataGrid.SelectedRows[0].Cells[2].Value.ToString();
                    typeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[3].Value.ToString();
                    artefactNameTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[4].Value.ToString();
                    cipherTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[5].Value.ToString();
                    dateOfRegistration.Text = artefactsDataGrid.SelectedRows[0].Cells[6].Value.ToString();
                    oldInventoryIdTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[7].Value.ToString();
                    shapeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[8].Value.ToString();
                    idOfActOfAdmissionTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[9].Value.ToString();
                    materialComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[10].Value.ToString();
                    techniqueTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[11].Value.ToString();
                    inscriptionOrDateTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[12].Value.ToString();
                    sizeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[13].Value.ToString();
                    weightTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[14].Value.ToString();
                    eraTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[15].Value.ToString();
                    conditionOfArtefactTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[16].Value.ToString();
                    amountOfArtefactTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[17].Value.ToString();
                    historicalEnquiryTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[18].Value.ToString();
                    sellerOrDonaterTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[19].Value.ToString();
                    assesmentProtocolIdComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[20].Value.ToString();
                    dateOfAssesmentProtocol.Text = artefactsDataGrid.SelectedRows[0].Cells[21].Value.ToString();
                    priceOfAssesmentProtocolTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[22].Value.ToString();
                    storageLocationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[23].Value.ToString();
                    locationOfFindingTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[24].Value.ToString();
                    idOfPhotoNegativeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[25].Value.ToString();
                    registrationIdOfNMFTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[26].Value.ToString();
                    bibliographicEnquiryTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[27].Value.ToString();
                    scientificPublicationsTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[28].Value.ToString();
                    conservationAndRestorationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[29].Value.ToString();
                    participationInExhibitionsTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[30].Value.ToString();
                    copiesMadeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[31].Value.ToString();
                    marriageProtocolAndActOfLiquidationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[32].Value.ToString();
                    madeTheScientificPassportTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[33].Value.ToString();
                    dateOfCreationOfTheScientificPassportTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[34].Value.ToString();
                    identificationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[35].Value.ToString();
                    pictureName = artefactsDataGrid.SelectedRows[0].Cells[36].Value.ToString();
                    fullDirection = chosenPictureAddress + "\\MuseumPictures\\" + pictureName;
                    pictureBox.ImageLocation = fullDirection;
                    /*PictureName1 = artefactsDataGrid.SelectedRows[0].Cells[37].Value.ToString();
                    PictureName2 = artefactsDataGrid.SelectedRows[0].Cells[38].Value.ToString();
                    PictureName3 = artefactsDataGrid.SelectedRows[0].Cells[39].Value.ToString();
                    PictureName4 = artefactsDataGrid.SelectedRows[0].Cells[40].Value.ToString();
                    PictureName5 = artefactsDataGrid.SelectedRows[0].Cells[41].Value.ToString();
                    pictures = new string[] { PictureName0, PictureName1, PictureName2, PictureName3, PictureName4, PictureName5 };
                    foreach (string item in pictures)
                    {
                        if (item != null)
                        {
                            var imageFromFile = Image.FromFile(chosenPictureAddress + "\\MuseumPictures\\" + item);
                            imageListArtefacts.Images.Add(imageFromFile);
                            pictureBox.Image = imageListArtefacts.Images[0];
                        }
                    }*/

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void picturebtn_Click(object sender, EventArgs e) //Добавя снимка към формата в PictureBox
        {
            if (openPictureFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox.ImageLocation = openPictureFileDialog.FileName.ToString();
                pictureName = Path.GetFileName(openPictureFileDialog.FileName);
                /*sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
                sqlConn.Open();
                sqlQuery = $"INSERT INTO rim_dobrich.images(artefact_id,image_details) SELECT id,pictureaddress " +
                   $"FROM rim_dobrich.artefacts ";
                   $"LEFT JOIN rim_dobrich.images ON rim_dobrich.images.artefact_id=rim_dobrich.artefacts.id "+
                   $"WHERE rim_dobrich.images.artefact_id='{indexTxt.Text}'";*/
            }
            /*   sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
               sqlRd = sqlCmd.ExecuteReader();
               sqlConn.Close();
           }*/
            /*Images images = new Images();
            Artefacts artefacts = new Artefacts();
            images.Show();
            this.Hide();
            artefacts.Close();*/

        }
        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Menu menu = new Menu();
            Artefacts artefactscs = new Artefacts();
            menu.Show();
            this.Hide();
            artefactscs.Close();
        }

        private void assesmentpridcb_SelectedIndexChanged(object sender, EventArgs e) //Автоматично се запълават dateOfAssesmentProtocol и priceOfAssesmentProtocolTxt с данните от таблицата assesmentprotocol по избрания индекс от assesmentProtocolIdComboBox
        {
            sqlConn.ConnectionString = $"server=127.0.0.1;user id=root;password=;database=rim_dobrich";
            sqlConn.Open();

            sqlCmd.Connection = sqlConn;
            if (assesmentProtocolIdComboBox.Text != string.Empty)
            {
                string id = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToUInt16(id);
                sqlQuery = $"SELECT * FROM rim_dobrich.assesmentprotocol WHERE assesmentpr_id={id}";
                sqlCmd.Parameters.AddWithValue(dateOfAssesmentProtocol.Text, "@assesmentpr_date");
                sqlCmd.Parameters.AddWithValue(priceOfAssesmentProtocolTxt.Text, "@assesmentpr_price");
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                if (sqlRd.Read())
                {
                    if (id != null)
                    {
                        dateOfAssesmentProtocol.Text = sqlRd.GetDateTime("assesmentpr_date").ToString();
                        priceOfAssesmentProtocolTxt.Text = sqlRd.GetString("assesmentpr_price");
                    }
                }
            }
            else
            {
                MessageBox.Show("No data");
            }
            sqlConn.Close();
        }
        private void searchBtn_Click(object sender, EventArgs e) //Търси по името на артефакта
        {
            try
            {
                DataView dv = sqlDT.DefaultView;
                dv.RowFilter = string.Format("`Инв. номер` like'%{0}%'", searchTxt.Text);
                artefactsDataGrid.DataSource = dv.ToTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неуспешно търсене на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e) //Връща началните стойности, занулира
        {
            indexTxt.Text = string.Empty;
            nameOfMuseumComboBox.Text = "Име на музей";
            collectionscb.Text = "Сбирки";
            typeComboBox.Text = "Видове артефакти";
            artefactNameTxt.Text = string.Empty;
            cipherTxt.Text = string.Empty;
            dateOfAssesmentProtocol.Text = string.Empty;
            oldInventoryIdTxt.Text = string.Empty;
            idOfActOfAdmissionTxt.Text = string.Empty;
            shapeComboBox.Text = "Форма";
            materialComboBox.Text = "Материал";
            techniqueTxt.Text = string.Empty;
            inscriptionOrDateTxt.Text = string.Empty;
            sizeTxt.Text = string.Empty;
            weightTxt.Text = string.Empty;
            eraTxt.Text = string.Empty;
            conditionOfArtefactTxt.Text = string.Empty;
            amountOfArtefactTxt.Text = string.Empty;
            historicalEnquiryTxt.Text = string.Empty;
            sellerOrDonaterTxt.Text = string.Empty;
            assesmentProtocolIdComboBox.Text = "№ ОП";
            dateOfRegistration.Text = string.Empty;
            priceOfAssesmentProtocolTxt.Text = string.Empty;
            storageLocationTxt.Text = string.Empty;
            locationOfFindingTxt.Text = string.Empty;
            idOfPhotoNegativeTxt.Text = string.Empty;
            registrationIdOfNMFTxt.Text = string.Empty;
            bibliographicEnquiryTxt.Text = string.Empty;
            scientificPublicationsTxt.Text = string.Empty;
            conservationAndRestorationTxt.Text = string.Empty;
            participationInExhibitionsTxt.Text = string.Empty;
            copiesMadeTxt.Text = string.Empty;
            marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
            madeTheScientificPassportTxt.Text = string.Empty;
            dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
            identificationTxt.Text = string.Empty;
            pictureBox.ImageLocation = string.Empty;
        }

        private void typeComboBox_Click(object sender, EventArgs e) //Изчиства текста в combobox-а
        {
            typeComboBox.Text = string.Empty;
        }
        private void typeComboBox_KeyDown(object sender, KeyEventArgs e) //Позволява търсене на вид артефакт по първата мъ буква
        {
            if (typeComboBox.Text != string.Empty)
            {

                int index = typeComboBox.FindString(typeComboBox.Text);

                if (e.KeyCode == Keys.Back)
                {
                    typeComboBox.Text = string.Empty;
                    UploadComboBoxTypes();
                }

            }
            else
            {
                UploadComboBoxTypes();
            }
        }

        private void typeComboBox_TextUpdate(object sender, EventArgs e)
        {
            if (typeComboBox.Text.Length > 0)
            {
                typeComboBox.MaxLength = 1;
            }
        }

        private void nameOfMuseumComboBox_KeyDown(object sender, KeyEventArgs e) //Премахва възможността за редаактиране на текста в combobox-а
        {
            e.SuppressKeyPress = true;
        }

        private void Artefacts_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Privilege == 3)
            {

                if (sectionNameComboBox.SelectedIndex + 1 == SectionId)
                {

                    indexTxt.Enabled = true;
                    nameOfMuseumComboBox.Enabled = true;
                    collectionscb.Enabled = true;
                    typeComboBox.Enabled = true;
                    artefactNameTxt.Enabled = true;
                    cipherTxt.Enabled = true;
                    oldInventoryIdTxt.Enabled = true;
                    idOfActOfAdmissionTxt.Enabled = true;
                    shapeComboBox.Enabled = true;
                    materialComboBox.Enabled = true;
                    techniqueTxt.Enabled = true;
                    inscriptionOrDateTxt.Enabled = true;
                    sizeTxt.Enabled = true;
                    weightTxt.Enabled = true;
                    eraTxt.Enabled = true;
                    conditionOfArtefactTxt.Enabled = true;
                    amountOfArtefactTxt.Enabled = true;
                    historicalEnquiryTxt.Enabled = true;
                    sellerOrDonaterTxt.Enabled = true;
                    assesmentProtocolIdComboBox.Enabled = true;
                    dateOfRegistration.Enabled = true;
                    storageLocationTxt.Enabled = true;
                    locationOfFindingTxt.Enabled = true;
                    idOfPhotoNegativeTxt.Enabled = true;
                    registrationIdOfNMFTxt.Enabled = true;
                    bibliographicEnquiryTxt.Enabled = true;
                    scientificPublicationsTxt.Enabled = true;
                    conservationAndRestorationTxt.Enabled = true;
                    participationInExhibitionsTxt.Enabled = true;
                    copiesMadeTxt.Enabled = true;
                    marriageProtocolAndActOfLiquidationTxt.Enabled = true;
                    madeTheScientificPassportTxt.Enabled = true;
                    dateOfCreationOfTheScientificPassportTxt.Enabled = true;
                    identificationTxt.Enabled = true;
                    addNewBtn.Enabled = true;
                    deleteBtn.Enabled = true;
                    resetBtn.Enabled = true;
                    updateBtn.Enabled = true;
                    pictureBtn.Enabled = true;

                }
                else
                {
                    indexTxt.Enabled = false;
                    nameOfMuseumComboBox.Enabled = false;
                    collectionscb.Enabled = false;
                    typeComboBox.Enabled = false;
                    artefactNameTxt.Enabled = false;
                    cipherTxt.Enabled = false;
                    dateOfAssesmentProtocol.Enabled = false;
                    oldInventoryIdTxt.Enabled = false;
                    idOfActOfAdmissionTxt.Enabled = false;
                    shapeComboBox.Enabled = false;
                    materialComboBox.Enabled = false;
                    techniqueTxt.Enabled = false;
                    inscriptionOrDateTxt.Enabled = false;
                    sizeTxt.Enabled = false;
                    weightTxt.Enabled = false;
                    eraTxt.Enabled = false;
                    conditionOfArtefactTxt.Enabled = false;
                    amountOfArtefactTxt.Enabled = false;
                    historicalEnquiryTxt.Enabled = false;
                    sellerOrDonaterTxt.Enabled = false;
                    assesmentProtocolIdComboBox.Enabled = false;
                    dateOfRegistration.Enabled = false;
                    priceOfAssesmentProtocolTxt.Enabled = false;
                    storageLocationTxt.Enabled = false;
                    locationOfFindingTxt.Enabled = false;
                    idOfPhotoNegativeTxt.Enabled = false;
                    registrationIdOfNMFTxt.Enabled = false;
                    bibliographicEnquiryTxt.Enabled = false;
                    scientificPublicationsTxt.Enabled = false;
                    conservationAndRestorationTxt.Enabled = false;
                    participationInExhibitionsTxt.Enabled = false;
                    copiesMadeTxt.Enabled = false;
                    marriageProtocolAndActOfLiquidationTxt.Enabled = false;
                    madeTheScientificPassportTxt.Enabled = false;
                    dateOfCreationOfTheScientificPassportTxt.Enabled = false;
                    identificationTxt.Enabled = false;
                    addNewBtn.Enabled = false;
                    deleteBtn.Enabled = false;
                    updateBtn.Enabled = false;
                    pictureBtn.Enabled = false;

                }
            }
            sqlDT.Rows.Clear();
            UploadData();
        }
        private void PrivilegeManagement()
        {
            this.tableLayoutPanel1.SetColumn(sectionNameComboBox, 0);
            this.tableLayoutPanel1.SetColumn(queriesBtn, 3);
            if (Privilege == 3)
            {
                menuBtn.Visible = false;
                this.tableLayoutPanel1.SetRow(artefactsDataGrid, 0);
                this.tableLayoutPanel1.SetRowSpan(artefactsDataGrid, 19);
                artefactsDataGrid.Size = new System.Drawing.Size(1112, 886);
            }
            else if (Privilege == 4)
            {
                indexTxt.Enabled = false;
                nameOfMuseumComboBox.Enabled = false;
                collectionscb.Enabled = false;
                typeComboBox.Enabled = false;
                artefactNameTxt.Enabled = false;
                cipherTxt.Enabled = false;
                dateOfAssesmentProtocol.Enabled = false;
                oldInventoryIdTxt.Enabled = false;
                idOfActOfAdmissionTxt.Enabled = false;
                shapeComboBox.Enabled = false;
                materialComboBox.Enabled = false;
                techniqueTxt.Enabled = false;
                inscriptionOrDateTxt.Enabled = false;
                sizeTxt.Enabled = false;
                weightTxt.Enabled = false;
                eraTxt.Enabled = false;
                conditionOfArtefactTxt.Enabled = false;
                amountOfArtefactTxt.Enabled = false;
                historicalEnquiryTxt.Enabled = false;
                sellerOrDonaterTxt.Enabled = false;
                assesmentProtocolIdComboBox.Enabled = false;
                dateOfRegistration.Enabled = false;
                priceOfAssesmentProtocolTxt.Enabled = false;
                storageLocationTxt.Enabled = false;
                locationOfFindingTxt.Enabled = false;
                idOfPhotoNegativeTxt.Enabled = false;
                registrationIdOfNMFTxt.Enabled = false;
                bibliographicEnquiryTxt.Enabled = false;
                scientificPublicationsTxt.Enabled = false;
                conservationAndRestorationTxt.Enabled = false;
                participationInExhibitionsTxt.Enabled = false;
                copiesMadeTxt.Enabled = false;
                marriageProtocolAndActOfLiquidationTxt.Enabled = false;
                madeTheScientificPassportTxt.Enabled = false;
                dateOfCreationOfTheScientificPassportTxt.Enabled = false;
                identificationTxt.Enabled = false;
                addNewBtn.Enabled = false;
                deleteBtn.Enabled = false;
                updateBtn.Enabled = false;
                pictureBtn.Enabled = false;
                this.tableLayoutPanel1.SetRow(typeComboBox, 3);
                this.tableLayoutPanel1.SetRow(artefactNameTxt, 3);
                this.tableLayoutPanel1.SetRow(shapeComboBox, 3);
                this.tableLayoutPanel1.SetColumn(shapeComboBox, 3);
                this.tableLayoutPanel1.SetRow(materialComboBox, 5);
                this.tableLayoutPanel1.SetRow(techniqueTxt, 5);
                this.tableLayoutPanel1.SetRow(inscriptionOrDateTxt, 7);
                this.tableLayoutPanel1.SetRow(sizeTxt, 10);
                this.tableLayoutPanel1.SetRow(weightTxt, 10);
                this.tableLayoutPanel1.SetColumnSpan(eraTxt, 2);
                eraTxt.Size = new System.Drawing.Size(365, 35);
                this.tableLayoutPanel1.SetRow(eraTxt, 10);
                this.tableLayoutPanel1.SetRow(pictureBox, 15);
                this.tableLayoutPanel1.SetRow(searchTxt, 18);
                this.tableLayoutPanel1.SetRow(searchBtn, 19);
                resetBtn.Size = new System.Drawing.Size(366, 37);
                this.tableLayoutPanel1.SetColumnSpan(resetBtn, 2);
                this.tableLayoutPanel1.SetRow(resetBtn, 20);
                this.tableLayoutPanel1.SetColumn(resetBtn, 0);
                this.tableLayoutPanel1.SetRow(artefactsDataGrid, 0);
                this.tableLayoutPanel1.SetRowSpan(artefactsDataGrid, 21);
                artefactsDataGrid.Size = new System.Drawing.Size(1112, 962);

                oldInventoryIdTxt.Visible = false;
                cipherTxt.Visible = false;
                idOfActOfAdmissionTxt.Visible = false;
                conditionOfArtefactTxt.Visible = false;
                amountOfArtefactTxt.Visible = false;
                historicalEnquiryTxt.Visible = false;
                sellerOrDonaterTxt.Visible = false;
                assesmentProtocolIdComboBox.Visible = false;
                dateOfAssesmentProtocol.Visible = false;
                priceOfAssesmentProtocolTxt.Visible = false;
                storageLocationTxt.Visible = false;
                locationOfFindingTxt.Visible = false;
                idOfPhotoNegativeTxt.Visible = false;
                registrationIdOfNMFTxt.Visible = false;
                bibliographicEnquiryTxt.Visible = false;
                scientificPublicationsTxt.Visible = false;
                conservationAndRestorationTxt.Visible = false;
                participationInExhibitionsTxt.Visible = false;
                copiesMadeTxt.Visible = false;
                marriageProtocolAndActOfLiquidationTxt.Enabled = false;
                madeTheScientificPassportTxt.Visible = false;
                dateOfCreationOfTheScientificPassportTxt.Visible = false;
                identificationTxt.Visible = false;
                marriageProtocolAndActOfLiquidationTxt.Visible = false;
                dateOfAssesmentProtocolLabel.Visible = false;
                dateOfCreationOfTheScientificPassportLabel.Visible = false;
                dateOfRegistration.Visible = false;
                dateOfRegistrationLabel.Visible = false;
                addNewBtn.Visible = false;
                deleteBtn.Visible = false;
                updateBtn.Visible = false;
                pictureBtn.Visible = false;
                menuBtn.Visible = false;
            }
        }

        private void queriesBtn_Click_1(object sender, EventArgs e)
        {
            Artefacts artefacts = new Artefacts();
            Queries queries = new Queries(SectionId, Privilege);
            queries.Show();
            this.Hide();
            artefacts.Close();
        }

        private void sectionNameComboBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }
        private void PictureAdding()
        {
            foreach (string i in pictures)
            {
                if (i != null)
                {
                    var imageFromFile = Image.FromFile(chosenPictureAddress + "\\MuseumPictures\\" + i);
                    imageListArtefacts.Images.Add(imageFromFile);
                }
            }

        }

        //int currentPic = 5;

        private void backPicBtn_Click(object sender, EventArgs e)
        {
            /*do
            {
                currentPic--;
                pictureBox.Image = imageListArtefacts.Images[currentPic];
            }
            while (currentPic != -1);
            currentPic = imageListArtefacts.Images.Count;*/
        }

        private void nextPicBtn_Click(object sender, EventArgs e)
        {
            /*while (currentPic != imageListArtefacts.Images.Count)
            {
                currentPic++;
                pictureBox.Image = imageListArtefacts.Images[currentPic];
            }
            if (currentPic == imageListArtefacts.Images.Count)
            {
                currentPic = 0;
            }*/
        }
    }
}
