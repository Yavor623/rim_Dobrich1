﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class Images : Form
    {
        public Images()
        {
            InitializeComponent();
        }
        string pictureName;
        string picture1Name;
        string picture2Name;
        string picture3Name;
        string picture4Name;
        string picture5Name;
        private void pictureBtn_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox.ImageLocation = openFileDialog1.FileName.ToString();
                pictureName = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox4.ImageLocation = openFileDialog1.FileName.ToString();
                picture4Name = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox3.ImageLocation = openFileDialog1.FileName.ToString();
                picture3Name = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.ImageLocation = openFileDialog1.FileName.ToString();
                picture2Name = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = openFileDialog1.FileName.ToString();
                picture1Name = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox5.ImageLocation = openFileDialog1.FileName.ToString();
                picture5Name = Path.GetFileName(openFileDialog1.FileName);
            }
        }

        private void artefactsBtn_Click(object sender, EventArgs e)
        {
            /*Images images = new Images();
            Artefacts artefacts = new Artefacts(pictureName, picture1Name, picture2Name, picture3Name, picture4Name, picture5Name);
            artefacts.Show();
            this.Hide();*/
        }
    }
}
