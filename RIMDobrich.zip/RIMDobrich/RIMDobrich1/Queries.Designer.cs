﻿namespace RIMDobrich1
{
    partial class Queries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Queries));
            queryChoiceComboBox = new ComboBox();
            queriesDataGrid = new DataGridView();
            typeOfColumnChoiceComboBox = new ComboBox();
            assesmentProtocolBtn = new Button();
            collectionsBtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesBtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            queriesBtn = new Button();
            countTxt = new TextBox();
            clearBtn = new Button();
            columnChoiceComboBox = new ComboBox();
            searchTxt = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)queriesDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // queryChoiceComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(queryChoiceComboBox, 3);
            queryChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            queryChoiceComboBox.FormattingEnabled = true;
            queryChoiceComboBox.Items.AddRange(new object[] { "Изведи всички", "Изведи броя на", "Търси по" });
            queryChoiceComboBox.Location = new Point(3, 95);
            queryChoiceComboBox.Name = "queryChoiceComboBox";
            queryChoiceComboBox.Size = new Size(534, 53);
            queryChoiceComboBox.TabIndex = 41;
            queryChoiceComboBox.TabStop = false;
            queryChoiceComboBox.Text = "Изберете вида на заявката";
            queryChoiceComboBox.SelectedIndexChanged += queryChoice_SelectedIndexChanged;
            queryChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // queriesDataGrid
            // 
            queriesDataGrid.AllowUserToAddRows = false;
            queriesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            queriesDataGrid.BackgroundColor = Color.Tan;
            queriesDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(queriesDataGrid, 7);
            queriesDataGrid.Cursor = Cursors.PanNW;
            queriesDataGrid.Location = new Point(555, 95);
            queriesDataGrid.MultiSelect = false;
            queriesDataGrid.Name = "queriesDataGrid";
            queriesDataGrid.ReadOnly = true;
            queriesDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(queriesDataGrid, 7);
            queriesDataGrid.RowTemplate.Height = 29;
            queriesDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            queriesDataGrid.Size = new Size(1286, 850);
            queriesDataGrid.TabIndex = 43;
            queriesDataGrid.TabStop = false;
            // 
            // typeOfColumnChoiceComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(typeOfColumnChoiceComboBox, 3);
            typeOfColumnChoiceComboBox.Enabled = false;
            typeOfColumnChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            typeOfColumnChoiceComboBox.FormattingEnabled = true;
            typeOfColumnChoiceComboBox.Location = new Point(3, 217);
            typeOfColumnChoiceComboBox.Name = "typeOfColumnChoiceComboBox";
            typeOfColumnChoiceComboBox.Size = new Size(534, 53);
            typeOfColumnChoiceComboBox.TabIndex = 44;
            typeOfColumnChoiceComboBox.TabStop = false;
            typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
            typeOfColumnChoiceComboBox.SelectedIndexChanged += columnChoice_SelectedIndexChanged;
            typeOfColumnChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Popup;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1291, 3);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(178, 49);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.TabStop = false;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.Cursor = Cursors.Hand;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Popup;
            collectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(1475, 3);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(178, 49);
            collectionsBtn.TabIndex = 34;
            collectionsBtn.TabStop = false;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Popup;
            museumsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1107, 3);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(178, 49);
            museumsBtn.TabIndex = 33;
            museumsBtn.TabStop = false;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Popup;
            artefactsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(187, 3);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 49);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.TabStop = false;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesBtn
            // 
            quieriesBtn.BackColor = Color.NavajoWhite;
            quieriesBtn.Cursor = Cursors.Hand;
            quieriesBtn.Enabled = false;
            quieriesBtn.FlatAppearance.BorderSize = 0;
            quieriesBtn.FlatStyle = FlatStyle.Popup;
            quieriesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesBtn.Location = new Point(1659, 3);
            quieriesBtn.Name = "quieriesBtn";
            quieriesBtn.Size = new Size(178, 49);
            quieriesBtn.TabIndex = 31;
            quieriesBtn.TabStop = false;
            quieriesBtn.Text = "Заявки";
            quieriesBtn.UseVisualStyleBackColor = false;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Popup;
            materialsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(923, 3);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(178, 49);
            materialsBtn.TabIndex = 30;
            materialsBtn.TabStop = false;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Popup;
            shapesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(739, 3);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(178, 49);
            shapesBtn.TabIndex = 29;
            shapesBtn.TabStop = false;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Popup;
            typesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(555, 3);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(178, 49);
            typesBtn.TabIndex = 28;
            typesBtn.TabStop = false;
            typesBtn.Text = "Видове";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Popup;
            sectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(371, 3);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(178, 49);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.TabStop = false;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Popup;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(178, 49);
            menuBtn.TabIndex = 0;
            menuBtn.TabStop = false;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // queriesBtn
            // 
            queriesBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            queriesBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(queriesBtn, 3);
            queriesBtn.Cursor = Cursors.Hand;
            queriesBtn.FlatStyle = FlatStyle.Flat;
            queriesBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            queriesBtn.Location = new Point(3, 751);
            queriesBtn.Name = "queriesBtn";
            queriesBtn.Size = new Size(534, 70);
            queriesBtn.TabIndex = 46;
            queriesBtn.TabStop = false;
            queriesBtn.Text = "Старт";
            queriesBtn.UseVisualStyleBackColor = false;
            queriesBtn.Click += queriesbtn_Click;
            // 
            // countTxt
            // 
            tableLayoutPanel1.SetColumnSpan(countTxt, 3);
            countTxt.Enabled = false;
            countTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            countTxt.Location = new Point(3, 461);
            countTxt.Multiline = true;
            countTxt.Name = "countTxt";
            countTxt.PlaceholderText = "Брой";
            countTxt.ReadOnly = true;
            countTxt.Size = new Size(534, 60);
            countTxt.TabIndex = 47;
            countTxt.TabStop = false;
            countTxt.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // clearBtn
            // 
            clearBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            clearBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(clearBtn, 3);
            clearBtn.Cursor = Cursors.Hand;
            clearBtn.FlatStyle = FlatStyle.Flat;
            clearBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            clearBtn.Location = new Point(3, 875);
            clearBtn.Name = "clearBtn";
            clearBtn.Size = new Size(534, 70);
            clearBtn.TabIndex = 49;
            clearBtn.TabStop = false;
            clearBtn.Text = "Изчисти";
            clearBtn.UseVisualStyleBackColor = false;
            clearBtn.Click += clearBtn_Click;
            // 
            // columnChoiceComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(columnChoiceComboBox, 3);
            columnChoiceComboBox.DropDownHeight = 250;
            columnChoiceComboBox.Enabled = false;
            columnChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            columnChoiceComboBox.FormattingEnabled = true;
            columnChoiceComboBox.IntegralHeight = false;
            columnChoiceComboBox.Location = new Point(3, 339);
            columnChoiceComboBox.Name = "columnChoiceComboBox";
            columnChoiceComboBox.Size = new Size(534, 53);
            columnChoiceComboBox.TabIndex = 50;
            columnChoiceComboBox.TabStop = false;
            columnChoiceComboBox.Text = "Изберете колона";
            columnChoiceComboBox.TextUpdate += columnChoiceComboBox_TextUpdate;
            columnChoiceComboBox.Click += columnChoiceComboBox_Click;
            columnChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // searchTxt
            // 
            tableLayoutPanel1.SetColumnSpan(searchTxt, 3);
            searchTxt.Enabled = false;
            searchTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(3, 583);
            searchTxt.Multiline = true;
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търсачка";
            searchTxt.Size = new Size(534, 60);
            searchTxt.TabIndex = 85;
            searchTxt.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(clearBtn, 0, 7);
            tableLayoutPanel1.Controls.Add(columnChoiceComboBox, 0, 3);
            tableLayoutPanel1.Controls.Add(queriesBtn, 0, 6);
            tableLayoutPanel1.Controls.Add(countTxt, 0, 4);
            tableLayoutPanel1.Controls.Add(searchTxt, 0, 5);
            tableLayoutPanel1.Controls.Add(quieriesBtn, 9, 0);
            tableLayoutPanel1.Controls.Add(collectionsBtn, 8, 0);
            tableLayoutPanel1.Controls.Add(assesmentProtocolBtn, 7, 0);
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(typeOfColumnChoiceComboBox, 0, 2);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(queryChoiceComboBox, 0, 1);
            tableLayoutPanel1.Controls.Add(museumsBtn, 6, 0);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(typesBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(materialsBtn, 5, 0);
            tableLayoutPanel1.Controls.Add(shapesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(queriesDataGrid, 3, 1);
            tableLayoutPanel1.Location = new Point(31, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 8;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 9.793815F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.8865976F));
            tableLayoutPanel1.Size = new Size(1844, 948);
            tableLayoutPanel1.TabIndex = 86;
            // 
            // Queries
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1024, 724);
            Name = "Queries";
            Text = "Заявки";
            Load += Queries_Load;
            ((System.ComponentModel.ISupportInitialize)queriesDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private ComboBox queryChoiceComboBox;
        private DataGridView queriesDataGrid;
        private ComboBox typeOfColumnChoiceComboBox;
        private Button assesmentProtocolBtn;
        private Button collectionsBtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesBtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button queriesBtn;
        private TextBox countTxt;
        private Button clearBtn;
        private ComboBox columnChoiceComboBox;
        private TextBox searchTxt;
        private TableLayoutPanel tableLayoutPanel1;
    }
}